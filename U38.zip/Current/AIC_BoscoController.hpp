#ifndef UE4SS_SDK_AIC_BoscoController_HPP
#define UE4SS_SDK_AIC_BoscoController_HPP

class AAIC_BoscoController_C : public ABoscoController
{
};

#endif
