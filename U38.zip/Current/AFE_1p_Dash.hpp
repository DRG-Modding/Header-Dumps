#ifndef UE4SS_SDK_AFE_1p_Dash_HPP
#define UE4SS_SDK_AFE_1p_Dash_HPP

class UAFE_1p_Dash_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
