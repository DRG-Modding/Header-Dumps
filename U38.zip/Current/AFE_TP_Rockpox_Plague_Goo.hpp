#ifndef UE4SS_SDK_AFE_TP_Rockpox_Plague_Goo_HPP
#define UE4SS_SDK_AFE_TP_Rockpox_Plague_Goo_HPP

class UAFE_TP_Rockpox_Plague_Goo_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
