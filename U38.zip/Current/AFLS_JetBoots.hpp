#ifndef UE4SS_SDK_AFLS_JetBoots_HPP
#define UE4SS_SDK_AFLS_JetBoots_HPP

class UAFLS_JetBoots_C : public USoundAfflictionEffect
{
};

#endif
