#ifndef UE4SS_SDK_AFL_Frozen_HydraWeed_Shooter_HPP
#define UE4SS_SDK_AFL_Frozen_HydraWeed_Shooter_HPP

class UAFL_Frozen_HydraWeed_Shooter_C : public UScalingMeshAfflictionEffect
{
};

#endif
