#ifndef UE4SS_SDK_ABP_Spider_Shooter_HPP
#define UE4SS_SDK_ABP_Spider_Shooter_HPP

class UABP_Spider_Shooter_C : public UABP_Spider_Shooting_C
{
};

#endif
