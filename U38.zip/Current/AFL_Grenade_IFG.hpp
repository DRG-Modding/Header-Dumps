#ifndef UE4SS_SDK_AFL_Grenade_IFG_HPP
#define UE4SS_SDK_AFL_Grenade_IFG_HPP

class UAFL_Grenade_IFG_C : public USoundAfflictionEffect
{
};

#endif
