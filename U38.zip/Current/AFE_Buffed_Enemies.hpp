#ifndef UE4SS_SDK_AFE_Buffed_Enemies_HPP
#define UE4SS_SDK_AFE_Buffed_Enemies_HPP

class UAFE_Buffed_Enemies_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
