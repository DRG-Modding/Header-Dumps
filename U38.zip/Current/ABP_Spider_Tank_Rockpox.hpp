#ifndef UE4SS_SDK_ABP_Spider_Tank_Rockpox_HPP
#define UE4SS_SDK_ABP_Spider_Tank_Rockpox_HPP

class UABP_Spider_Tank_Rockpox_C : public UABP_Spider_Tank_C
{
};

#endif
