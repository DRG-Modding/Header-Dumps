#ifndef UE4SS_SDK_AFE_FP_MagicHoleMovement_HPP
#define UE4SS_SDK_AFE_FP_MagicHoleMovement_HPP

class UAFE_FP_MagicHoleMovement_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
