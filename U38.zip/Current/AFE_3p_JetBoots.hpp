#ifndef UE4SS_SDK_AFE_3p_JetBoots_HPP
#define UE4SS_SDK_AFE_3p_JetBoots_HPP

class UAFE_3p_JetBoots_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
