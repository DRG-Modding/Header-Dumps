#ifndef UE4SS_SDK_ABP_MobilePlague_UniqueHead_B_HPP
#define UE4SS_SDK_ABP_MobilePlague_UniqueHead_B_HPP

class UABP_MobilePlague_UniqueHead_B_C : public UABP_MobilePlague_UniqueHead_A_C
{
};

#endif
