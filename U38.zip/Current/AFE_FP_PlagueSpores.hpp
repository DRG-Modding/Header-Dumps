#ifndef UE4SS_SDK_AFE_FP_PlagueSpores_HPP
#define UE4SS_SDK_AFE_FP_PlagueSpores_HPP

class UAFE_FP_PlagueSpores_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
