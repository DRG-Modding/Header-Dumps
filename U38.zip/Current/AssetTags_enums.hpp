enum class ECollectionScriptingShareType {
    Local = 0,
    Private = 1,
    Shared = 2,
    ECollectionScriptingShareType_MAX = 3,
};

