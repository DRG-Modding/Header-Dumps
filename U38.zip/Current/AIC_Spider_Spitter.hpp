#ifndef UE4SS_SDK_AIC_Spider_Spitter_HPP
#define UE4SS_SDK_AIC_Spider_Spitter_HPP

class AAIC_Spider_Spitter_C : public AAIC_Spider_C
{
};

#endif
