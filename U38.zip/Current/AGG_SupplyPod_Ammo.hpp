#ifndef UE4SS_SDK_AGG_SupplyPod_Ammo_HPP
#define UE4SS_SDK_AGG_SupplyPod_Ammo_HPP

class UAGG_SupplyPod_Ammo_C : public UItemPlacerAggregator
{
};

#endif
