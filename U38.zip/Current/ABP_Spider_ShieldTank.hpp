#ifndef UE4SS_SDK_ABP_Spider_ShieldTank_HPP
#define UE4SS_SDK_ABP_Spider_ShieldTank_HPP

class UABP_Spider_ShieldTank_C : public UABP_Spider_Tank_C
{
};

#endif
