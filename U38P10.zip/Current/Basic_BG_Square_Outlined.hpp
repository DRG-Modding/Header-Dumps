#ifndef UE4SS_SDK_Basic_BG_Square_Outlined_HPP
#define UE4SS_SDK_Basic_BG_Square_Outlined_HPP

class UBasic_BG_Square_Outlined_C : public UUserWidget
{
    class UImage* Image_191;
    class UImage* Image_324;
    class UImage* Image_438;
    class UImage* Image_503;
    class UImage* Image_1431;
    class UImage* Image_1548;
    class UImage* Image_1550;

};

#endif
