#ifndef UE4SS_SDK_AFLS_ShieldBoost_Activation_HPP
#define UE4SS_SDK_AFLS_ShieldBoost_Activation_HPP

class UAFLS_ShieldBoost_Activation_C : public USoundAfflictionEffect
{
};

#endif
