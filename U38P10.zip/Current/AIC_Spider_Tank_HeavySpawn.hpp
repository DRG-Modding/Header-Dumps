#ifndef UE4SS_SDK_AIC_Spider_Tank_HeavySpawn_HPP
#define UE4SS_SDK_AIC_Spider_Tank_HeavySpawn_HPP

class AAIC_Spider_Tank_HeavySpawn_C : public AAIC_Spider_C
{
};

#endif
