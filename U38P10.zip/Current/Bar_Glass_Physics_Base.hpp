#ifndef UE4SS_SDK_Bar_Glass_Physics_Base_HPP
#define UE4SS_SDK_Bar_Glass_Physics_Base_HPP

class ABar_Glass_Physics_Base_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;

};

#endif
