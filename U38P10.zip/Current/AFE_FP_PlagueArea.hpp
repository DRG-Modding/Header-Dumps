#ifndef UE4SS_SDK_AFE_FP_PlagueArea_HPP
#define UE4SS_SDK_AFE_FP_PlagueArea_HPP

class UAFE_FP_PlagueArea_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
