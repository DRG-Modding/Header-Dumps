#ifndef UE4SS_SDK_AIC_Spider_Stinger_HPP
#define UE4SS_SDK_AIC_Spider_Stinger_HPP

class AAIC_Spider_Stinger_C : public AAIC_Spider_C
{
};

#endif
