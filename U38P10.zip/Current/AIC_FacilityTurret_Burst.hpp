#ifndef UE4SS_SDK_AIC_FacilityTurret_Burst_HPP
#define UE4SS_SDK_AIC_FacilityTurret_Burst_HPP

class AAIC_FacilityTurret_Burst_C : public AFacilityTurretController
{
};

#endif
