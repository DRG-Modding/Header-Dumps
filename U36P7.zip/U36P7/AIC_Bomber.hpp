#ifndef UE4SS_SDK_AIC_Bomber_HPP
#define UE4SS_SDK_AIC_Bomber_HPP

class AAIC_Bomber_C : public AFSDFlyingBugController
{
};

#endif
