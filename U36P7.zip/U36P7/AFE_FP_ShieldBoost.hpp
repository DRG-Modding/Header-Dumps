#ifndef UE4SS_SDK_AFE_FP_ShieldBoost_HPP
#define UE4SS_SDK_AFE_FP_ShieldBoost_HPP

class UAFE_FP_ShieldBoost_C : public UCameraParticleAfflictionEffect
{
};

#endif
