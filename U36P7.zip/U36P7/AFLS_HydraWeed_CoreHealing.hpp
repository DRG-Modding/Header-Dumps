#ifndef UE4SS_SDK_AFLS_HydraWeed_CoreHealing_HPP
#define UE4SS_SDK_AFLS_HydraWeed_CoreHealing_HPP

class UAFLS_HydraWeed_CoreHealing_C : public USoundAfflictionEffect
{
};

#endif
