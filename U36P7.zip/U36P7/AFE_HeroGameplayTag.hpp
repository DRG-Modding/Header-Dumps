#ifndef UE4SS_SDK_AFE_HeroGameplayTag_HPP
#define UE4SS_SDK_AFE_HeroGameplayTag_HPP

class UAFE_HeroGameplayTag_C : public UHeroEnemyAfflictionEffect
{
};

#endif
