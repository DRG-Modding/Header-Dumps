#ifndef UE4SS_SDK_AIC_InfectedMule_HPP
#define UE4SS_SDK_AIC_InfectedMule_HPP

class AAIC_InfectedMule_C : public AConvertedRobotController
{
};

#endif
