#ifndef UE4SS_SDK_AFE_TP_PheromonesFP_HPP
#define UE4SS_SDK_AFE_TP_PheromonesFP_HPP

class UAFE_TP_PheromonesFP_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
