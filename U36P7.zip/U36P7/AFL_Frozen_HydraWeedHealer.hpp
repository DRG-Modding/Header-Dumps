#ifndef UE4SS_SDK_AFL_Frozen_HydraWeedHealer_HPP
#define UE4SS_SDK_AFL_Frozen_HydraWeedHealer_HPP

class UAFL_Frozen_HydraWeedHealer_C : public UFrozenAfflictionEffect
{
};

#endif
