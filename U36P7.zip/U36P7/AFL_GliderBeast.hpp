#ifndef UE4SS_SDK_AFL_GliderBeast_HPP
#define UE4SS_SDK_AFL_GliderBeast_HPP

class UAFL_GliderBeast_C : public UFrozenAfflictionEffect
{
};

#endif
