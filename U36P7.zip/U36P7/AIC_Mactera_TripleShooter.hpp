#ifndef UE4SS_SDK_AIC_Mactera_TripleShooter_HPP
#define UE4SS_SDK_AIC_Mactera_TripleShooter_HPP

class AAIC_Mactera_TripleShooter_C : public AAIC_Mactera_Shooter_C
{
};

#endif
