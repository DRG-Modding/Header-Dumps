#ifndef UE4SS_SDK_AIC_Spider_Tank_Rock_HPP
#define UE4SS_SDK_AIC_Spider_Tank_Rock_HPP

class AAIC_Spider_Tank_Rock_C : public AAIC_Spider_Tank_Base_C
{
};

#endif
