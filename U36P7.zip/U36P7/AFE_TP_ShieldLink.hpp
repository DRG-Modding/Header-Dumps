#ifndef UE4SS_SDK_AFE_TP_ShieldLink_HPP
#define UE4SS_SDK_AFE_TP_ShieldLink_HPP

class UAFE_TP_ShieldLink_C : public UShieldLinkedAfflictionEffect
{
};

#endif
