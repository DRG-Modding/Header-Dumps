#ifndef UE4SS_SDK_AFE_TP_Chilled_HPP
#define UE4SS_SDK_AFE_TP_Chilled_HPP

class UAFE_TP_Chilled_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
