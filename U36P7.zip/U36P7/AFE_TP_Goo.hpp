#ifndef UE4SS_SDK_AFE_TP_Goo_HPP
#define UE4SS_SDK_AFE_TP_Goo_HPP

class UAFE_TP_Goo_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
