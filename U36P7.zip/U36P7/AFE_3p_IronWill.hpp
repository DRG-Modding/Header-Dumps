#ifndef UE4SS_SDK_AFE_3p_IronWill_HPP
#define UE4SS_SDK_AFE_3p_IronWill_HPP

class UAFE_3p_IronWill_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
