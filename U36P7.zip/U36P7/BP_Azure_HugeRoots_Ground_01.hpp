#ifndef UE4SS_SDK_BP_Azure_HugeRoots_Ground_01_HPP
#define UE4SS_SDK_BP_Azure_HugeRoots_Ground_01_HPP

class ABP_Azure_HugeRoots_Ground_01_C : public ABP_Azure_HureRoots_Base_C
{
};

#endif
