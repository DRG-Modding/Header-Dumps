#ifndef UE4SS_SDK_AFE_HeroEnemies_HPP
#define UE4SS_SDK_AFE_HeroEnemies_HPP

class UAFE_HeroEnemies_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
