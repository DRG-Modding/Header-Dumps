#ifndef UE4SS_SDK_AFL_Gen_Burn_Huge_HPP
#define UE4SS_SDK_AFL_Gen_Burn_Huge_HPP

class UAFL_Gen_Burn_Huge_C : public UBurningAfflictionEffect
{
};

#endif
