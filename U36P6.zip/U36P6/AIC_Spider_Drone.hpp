#ifndef UE4SS_SDK_AIC_Spider_Drone_HPP
#define UE4SS_SDK_AIC_Spider_Drone_HPP

class AAIC_Spider_Drone_C : public AAIC_Spider_C
{
};

#endif
