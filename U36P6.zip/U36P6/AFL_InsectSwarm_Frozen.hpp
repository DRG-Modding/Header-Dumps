#ifndef UE4SS_SDK_AFL_InsectSwarm_Frozen_HPP
#define UE4SS_SDK_AFL_InsectSwarm_Frozen_HPP

class UAFL_InsectSwarm_Frozen_C : public UFrozenAfflictionEffect
{
};

#endif
