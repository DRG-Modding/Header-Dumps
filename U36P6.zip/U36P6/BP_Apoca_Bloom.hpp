#ifndef UE4SS_SDK_BP_Apoca_Bloom_HPP
#define UE4SS_SDK_BP_Apoca_Bloom_HPP

class ABP_Apoca_Bloom_C : public ABP_Collectible_Simple_C
{
};

#endif
