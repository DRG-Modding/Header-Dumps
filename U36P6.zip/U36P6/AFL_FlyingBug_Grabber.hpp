#ifndef UE4SS_SDK_AFL_FlyingBug_Grabber_HPP
#define UE4SS_SDK_AFL_FlyingBug_Grabber_HPP

class UAFL_FlyingBug_Grabber_C : public UFrozenAfflictionEffect
{
};

#endif
