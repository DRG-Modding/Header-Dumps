#ifndef UE4SS_SDK_Basic_BG_Square_Outline_Flat_HPP
#define UE4SS_SDK_Basic_BG_Square_Outline_Flat_HPP

class UBasic_BG_Square_Outline_Flat_C : public UUserWidget
{
    class UImage* Image_102;
    class UImage* Image_184;

};

#endif
