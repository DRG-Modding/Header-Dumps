#ifndef UE4SS_SDK_AFE_FP_Burning_HPP
#define UE4SS_SDK_AFE_FP_Burning_HPP

class UAFE_FP_Burning_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
