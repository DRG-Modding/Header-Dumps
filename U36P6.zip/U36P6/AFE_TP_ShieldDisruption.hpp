#ifndef UE4SS_SDK_AFE_TP_ShieldDisruption_HPP
#define UE4SS_SDK_AFE_TP_ShieldDisruption_HPP

class UAFE_TP_ShieldDisruption_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
