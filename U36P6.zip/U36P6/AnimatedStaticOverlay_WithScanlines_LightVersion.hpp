#ifndef UE4SS_SDK_AnimatedStaticOverlay_WithScanlines_LightVersion_HPP
#define UE4SS_SDK_AnimatedStaticOverlay_WithScanlines_LightVersion_HPP

class UAnimatedStaticOverlay_WithScanlines_LightVersion_C : public UUserWidget
{
    class UImage* BorderGradient;
    class UImage* Static;

};

#endif
