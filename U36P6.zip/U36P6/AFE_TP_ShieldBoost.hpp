#ifndef UE4SS_SDK_AFE_TP_ShieldBoost_HPP
#define UE4SS_SDK_AFE_TP_ShieldBoost_HPP

class UAFE_TP_ShieldBoost_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
