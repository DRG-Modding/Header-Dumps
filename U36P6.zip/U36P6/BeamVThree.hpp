#ifndef UE4SS_SDK_BeamVThree_HPP
#define UE4SS_SDK_BeamVThree_HPP

struct FBeamVThree
{
    class UParticleSystemComponent* BeamEffect_7_E267E8B840AA60A09BB205800044B109;
    class UCapsuleComponent* Collider_6_29FA8C0441D915325BFC7392C31D369B;

};

#endif
