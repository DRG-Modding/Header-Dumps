#ifndef UE4SS_SDK_BP_Azure_HugeRoots_SingleGround_04_HPP
#define UE4SS_SDK_BP_Azure_HugeRoots_SingleGround_04_HPP

class ABP_Azure_HugeRoots_SingleGround_04_C : public ABP_Azure_HureRoots_Base_C
{
};

#endif
