#ifndef UE4SS_SDK_BP_Actor_Macros_HPP
#define UE4SS_SDK_BP_Actor_Macros_HPP

class ABP_Actor_Macros_C : public AActor
{
};

#endif
