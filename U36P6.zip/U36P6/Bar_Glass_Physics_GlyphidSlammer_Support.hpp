#ifndef UE4SS_SDK_Bar_Glass_Physics_GlyphidSlammer_Support_HPP
#define UE4SS_SDK_Bar_Glass_Physics_GlyphidSlammer_Support_HPP

class ABar_Glass_Physics_GlyphidSlammer_Support_C : public ABar_Glass_Physics_C
{

    void UserConstructionScript();
};

#endif
