#ifndef UE4SS_SDK_BML_InputHandling_HPP
#define UE4SS_SDK_BML_InputHandling_HPP

class UBML_InputHandling_C : public UUserWidget
{
};

#endif
