#ifndef UE4SS_SDK_ABP_Spider_Boss_HPP
#define UE4SS_SDK_ABP_Spider_Boss_HPP

class UABP_Spider_Boss_C : public UABP_Spider_Locomotion_C
{
};

#endif
