#ifndef UE4SS_SDK_BP_Audio_Macros_HPP
#define UE4SS_SDK_BP_Audio_Macros_HPP

class ABP_Audio_Macros_C : public AActor
{
};

#endif
