#ifndef UE4SS_SDK_AIC_SniperFacilityTurretDrone_HPP
#define UE4SS_SDK_AIC_SniperFacilityTurretDrone_HPP

class AAIC_SniperFacilityTurretDrone_C : public AAIC_FacilityTurretDrone_C
{
};

#endif
