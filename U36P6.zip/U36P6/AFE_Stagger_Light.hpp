#ifndef UE4SS_SDK_AFE_Stagger_Light_HPP
#define UE4SS_SDK_AFE_Stagger_Light_HPP

class UAFE_Stagger_Light_C : public UStaggeredAfflictionEffect
{
};

#endif
