#ifndef UE4SS_SDK_AFE_TP_GooPlant_HPP
#define UE4SS_SDK_AFE_TP_GooPlant_HPP

class UAFE_TP_GooPlant_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
