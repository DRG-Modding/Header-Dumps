#ifndef UE4SS_SDK_AFE_Burning_HPP
#define UE4SS_SDK_AFE_Burning_HPP

class UAFE_Burning_C : public UPawnBurningUniqueAfflictionEffect
{
};

#endif
