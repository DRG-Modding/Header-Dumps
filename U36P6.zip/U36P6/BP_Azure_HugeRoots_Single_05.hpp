#ifndef UE4SS_SDK_BP_Azure_HugeRoots_Single_05_HPP
#define UE4SS_SDK_BP_Azure_HugeRoots_Single_05_HPP

class ABP_Azure_HugeRoots_Single_05_C : public ABP_Azure_HureRoots_Base_C
{
};

#endif
