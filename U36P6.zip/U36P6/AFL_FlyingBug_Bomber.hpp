#ifndef UE4SS_SDK_AFL_FlyingBug_Bomber_HPP
#define UE4SS_SDK_AFL_FlyingBug_Bomber_HPP

class UAFL_FlyingBug_Bomber_C : public UFrozenAfflictionEffect
{
};

#endif
