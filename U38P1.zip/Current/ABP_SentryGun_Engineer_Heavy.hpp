#ifndef UE4SS_SDK_ABP_SentryGun_Engineer_Heavy_HPP
#define UE4SS_SDK_ABP_SentryGun_Engineer_Heavy_HPP

class UABP_SentryGun_Engineer_Heavy_C : public UABP_SentryGun_Engineer_C
{
};

#endif
