#ifndef UE4SS_SDK_AIC_JellyBreeder_HPP
#define UE4SS_SDK_AIC_JellyBreeder_HPP

class AAIC_JellyBreeder_C : public AFSDFlyingBugController
{
};

#endif
