#ifndef UE4SS_SDK_AFE_TP_GooCannon_DoT_HPP
#define UE4SS_SDK_AFE_TP_GooCannon_DoT_HPP

class UAFE_TP_GooCannon_DoT_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
