enum class EActorSequenceObjectReferenceType {
    ContextActor = 0,
    ExternalActor = 1,
    Component = 2,
    EActorSequenceObjectReferenceType_MAX = 3,
};

