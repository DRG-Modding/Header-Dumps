#ifndef UE4SS_SDK_AFE_TP_SentinelGoo_HPP
#define UE4SS_SDK_AFE_TP_SentinelGoo_HPP

class UAFE_TP_SentinelGoo_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
