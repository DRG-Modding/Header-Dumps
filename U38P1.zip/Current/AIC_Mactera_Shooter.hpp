#ifndef UE4SS_SDK_AIC_Mactera_Shooter_HPP
#define UE4SS_SDK_AIC_Mactera_Shooter_HPP

class AAIC_Mactera_Shooter_C : public AFSDFlyingBugController
{
};

#endif
