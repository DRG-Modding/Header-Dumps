#ifndef UE4SS_SDK_AFE_FP_PlagueTentacles_HPP
#define UE4SS_SDK_AFE_FP_PlagueTentacles_HPP

class UAFE_FP_PlagueTentacles_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
