#ifndef UE4SS_SDK_AFE_TP_SepticAcid_HPP
#define UE4SS_SDK_AFE_TP_SepticAcid_HPP

class UAFE_TP_SepticAcid_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
