#ifndef UE4SS_SDK_AFE_3p_Dash_HPP
#define UE4SS_SDK_AFE_3p_Dash_HPP

class UAFE_3p_Dash_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
