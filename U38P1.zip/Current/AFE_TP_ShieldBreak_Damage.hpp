#ifndef UE4SS_SDK_AFE_TP_ShieldBreak_Damage_HPP
#define UE4SS_SDK_AFE_TP_ShieldBreak_Damage_HPP

class UAFE_TP_ShieldBreak_Damage_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
