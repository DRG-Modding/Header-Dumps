#ifndef UE4SS_SDK_AFL_InfectedPlayer_Particle_HPP
#define UE4SS_SDK_AFL_InfectedPlayer_Particle_HPP

class UAFL_InfectedPlayer_Particle_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
