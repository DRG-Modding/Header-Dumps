#ifndef UE4SS_SDK_AIC_Spider_Stalker_HPP
#define UE4SS_SDK_AIC_Spider_Stalker_HPP

class AAIC_Spider_Stalker_C : public AAIC_Spider_C
{
};

#endif
