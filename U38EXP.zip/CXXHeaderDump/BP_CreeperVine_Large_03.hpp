#ifndef UE4SS_SDK_BP_CreeperVine_Large_03_HPP
#define UE4SS_SDK_BP_CreeperVine_Large_03_HPP

class ABP_CreeperVine_Large_03_C : public ABP_CreeperVine_Base_C
{
};

#endif
