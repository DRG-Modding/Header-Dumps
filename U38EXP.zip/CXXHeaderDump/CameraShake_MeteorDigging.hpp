#ifndef UE4SS_SDK_CameraShake_MeteorDigging_HPP
#define UE4SS_SDK_CameraShake_MeteorDigging_HPP

class UCameraShake_MeteorDigging_C : public UMatineeCameraShake
{
};

#endif
