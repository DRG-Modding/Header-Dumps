namespace ENiagara_EmitterLocSamplingMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagara_MAX = 2,
    };
}

