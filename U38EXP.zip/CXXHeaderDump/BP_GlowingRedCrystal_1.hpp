#ifndef UE4SS_SDK_BP_GlowingRedCrystal_1_HPP
#define UE4SS_SDK_BP_GlowingRedCrystal_1_HPP

class ABP_GlowingRedCrystal_1_C : public ABP_GlowingBlueCrystal_Base_C
{
};

#endif
