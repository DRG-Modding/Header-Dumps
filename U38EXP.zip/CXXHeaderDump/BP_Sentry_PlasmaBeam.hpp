#ifndef UE4SS_SDK_BP_Sentry_PlasmaBeam_HPP
#define UE4SS_SDK_BP_Sentry_PlasmaBeam_HPP

class ABP_Sentry_PlasmaBeam_C : public ASentryElectroBeam
{
};

#endif
