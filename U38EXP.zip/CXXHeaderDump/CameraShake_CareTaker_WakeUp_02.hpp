#ifndef UE4SS_SDK_CameraShake_CareTaker_WakeUp_02_HPP
#define UE4SS_SDK_CameraShake_CareTaker_WakeUp_02_HPP

class UCameraShake_CareTaker_WakeUp_02_C : public UMatineeCameraShake
{
};

#endif
