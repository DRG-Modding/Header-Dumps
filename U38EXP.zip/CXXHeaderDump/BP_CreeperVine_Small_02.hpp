#ifndef UE4SS_SDK_BP_CreeperVine_Small_02_HPP
#define UE4SS_SDK_BP_CreeperVine_Small_02_HPP

class ABP_CreeperVine_Small_02_C : public ABP_CreeperVine_Base_C
{
};

#endif
