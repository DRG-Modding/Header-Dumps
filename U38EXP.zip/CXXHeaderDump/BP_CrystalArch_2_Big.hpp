#ifndef UE4SS_SDK_BP_CrystalArch_2_Big_HPP
#define UE4SS_SDK_BP_CrystalArch_2_Big_HPP

class ABP_CrystalArch_2_Big_C : public ABP_CrystalArch_Base_C
{

    void UserConstructionScript();
};

#endif
