#ifndef UE4SS_SDK_CP_BeachParty2023_HPP
#define UE4SS_SDK_CP_BeachParty2023_HPP

class UCP_BeachParty2023_C : public UCampaign
{
};

#endif
