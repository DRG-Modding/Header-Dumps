namespace ENiagaraSUbUVAnimationMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraSUbUVAnimationMode_MAX = 2,
    };
}

