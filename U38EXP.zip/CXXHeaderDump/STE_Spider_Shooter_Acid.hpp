#ifndef UE4SS_SDK_STE_Spider_Shooter_Acid_HPP
#define UE4SS_SDK_STE_Spider_Shooter_Acid_HPP

class USTE_Spider_Shooter_Acid_C : public UStatusEffect
{
};

#endif
