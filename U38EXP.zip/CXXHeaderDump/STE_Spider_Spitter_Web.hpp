#ifndef UE4SS_SDK_STE_Spider_Spitter_Web_HPP
#define UE4SS_SDK_STE_Spider_Spitter_Web_HPP

class USTE_Spider_Spitter_Web_C : public UStatusEffect
{
};

#endif
