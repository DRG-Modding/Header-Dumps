#ifndef UE4SS_SDK_BP_NausicaaTreeTrunk_5-small_HPP
#define UE4SS_SDK_BP_NausicaaTreeTrunk_5-small_HPP

class ABP_NausicaaTreeTrunk_5-small_C : public ABP_NausicaaTreeTrunk_Base_C
{
};

#endif
