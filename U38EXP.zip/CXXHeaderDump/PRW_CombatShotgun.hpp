#ifndef UE4SS_SDK_PRW_CombatShotgun_HPP
#define UE4SS_SDK_PRW_CombatShotgun_HPP

class APRW_CombatShotgun_C : public AItemPreviewActor
{
    class USkeletalMeshComponent* SkeletalMesh;
    class USceneComponent* DefaultSceneRoot;

};

#endif
