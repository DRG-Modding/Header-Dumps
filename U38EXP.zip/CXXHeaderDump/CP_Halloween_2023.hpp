#ifndef UE4SS_SDK_CP_Halloween_2023_HPP
#define UE4SS_SDK_CP_Halloween_2023_HPP

class UCP_Halloween_2023_C : public UCampaign
{
};

#endif
