#ifndef UE4SS_SDK_BP_SeasonsConsole_HPP
#define UE4SS_SDK_BP_SeasonsConsole_HPP

class ABP_SeasonsConsole_C : public ABP_BaseSpaceRigConsole_C
{
    class UWidgetComponent* Widget_SeasonTerminal;
    class UPointLightComponent* PointLight4;
    class UPointLightComponent* PointLight3;
    class UPointLightComponent* PointLight2;
    class UPointLightComponent* PointLight1;
    class UWidgetComponent* Widget_NextReward;
    class UWidgetComponent* Widget_Progress;

};

#endif
