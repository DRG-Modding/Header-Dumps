#ifndef UE4SS_SDK_BP_DropPod_LandingZone_HPP
#define UE4SS_SDK_BP_DropPod_LandingZone_HPP

class ABP_DropPod_LandingZone_C : public AActor
{
    class UDecalComponent* Decal;
    class USkeletalMeshComponent* SkeletalMeshComponent0;

};

#endif
