#ifndef UE4SS_SDK_BP_Donkey_Salvage_HPP
#define UE4SS_SDK_BP_Donkey_Salvage_HPP

class ABP_Donkey_Salvage_C : public ABP_Donkey_C
{
};

#endif
