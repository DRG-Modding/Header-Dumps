#ifndef UE4SS_SDK_ITM_BarGlass_Item_DUMMY_HPP
#define UE4SS_SDK_ITM_BarGlass_Item_DUMMY_HPP

class AITM_BarGlass_Item_DUMMY_C : public AITM_BarGlass_Item_C
{
};

#endif
