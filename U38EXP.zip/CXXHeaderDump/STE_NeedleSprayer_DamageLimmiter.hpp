#ifndef UE4SS_SDK_STE_NeedleSprayer_DamageLimmiter_HPP
#define UE4SS_SDK_STE_NeedleSprayer_DamageLimmiter_HPP

class USTE_NeedleSprayer_DamageLimmiter_C : public UStatusEffect
{
};

#endif
