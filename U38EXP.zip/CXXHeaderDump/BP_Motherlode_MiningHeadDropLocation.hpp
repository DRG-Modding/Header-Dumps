#ifndef UE4SS_SDK_BP_Motherlode_MiningHeadDropLocation_HPP
#define UE4SS_SDK_BP_Motherlode_MiningHeadDropLocation_HPP

class ABP_Motherlode_MiningHeadDropLocation_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
