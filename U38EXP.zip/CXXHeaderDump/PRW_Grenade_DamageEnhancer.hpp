#ifndef UE4SS_SDK_PRW_Grenade_DamageEnhancer_HPP
#define UE4SS_SDK_PRW_Grenade_DamageEnhancer_HPP

class APRW_Grenade_DamageEnhancer_C : public APRW_Grenade_Base_C
{
};

#endif
