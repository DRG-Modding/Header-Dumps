#ifndef UE4SS_SDK_BP_PetUseSphere_HPP
#define UE4SS_SDK_BP_PetUseSphere_HPP

class UBP_PetUseSphere_C : public UBeastMasterUseSphere
{
};

#endif
