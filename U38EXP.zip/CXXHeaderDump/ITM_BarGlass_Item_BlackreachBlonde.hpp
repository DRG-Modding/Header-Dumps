#ifndef UE4SS_SDK_ITM_BarGlass_Item_BlackreachBlonde_HPP
#define UE4SS_SDK_ITM_BarGlass_Item_BlackreachBlonde_HPP

class AITM_BarGlass_Item_BlackreachBlonde_C : public AITM_BarGlass_Item_C
{
};

#endif
