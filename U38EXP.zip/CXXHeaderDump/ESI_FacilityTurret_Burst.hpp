#ifndef UE4SS_SDK_ESI_FacilityTurret_Burst_HPP
#define UE4SS_SDK_ESI_FacilityTurret_Burst_HPP

class AESI_FacilityTurret_Burst_C : public AEnemyShowroomItem
{
    class UStaticMeshComponent* StaticMesh;
    class USkeletalMeshComponent* SkeletalMesh;
    class UStaticMeshComponent* SM_Stone_007;
    class USceneComponent* DefaultSceneRoot;

};

#endif
