#ifndef UE4SS_SDK_DNA_2_02_HPP
#define UE4SS_SDK_DNA_2_02_HPP

class UDNA_2_02_C : public UMissionDNA
{
};

#endif
