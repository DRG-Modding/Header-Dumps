#ifndef UE4SS_SDK_CameraShake_Item_PickAxe_HPP
#define UE4SS_SDK_CameraShake_Item_PickAxe_HPP

class UCameraShake_Item_PickAxe_C : public UMatineeCameraShake
{
};

#endif
