#ifndef UE4SS_SDK_BP_SmallLavaGeyserFiledOrigin_HPP
#define UE4SS_SDK_BP_SmallLavaGeyserFiledOrigin_HPP

class ABP_SmallLavaGeyserFiledOrigin_C : public AActor
{
    class USphereComponent* Sphere;
    class UTerrainPlacementComponent* terrainPlacement;
    class USceneComponent* DefaultSceneRoot;

};

#endif
