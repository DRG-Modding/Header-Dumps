#ifndef UE4SS_SDK_CameraShake_SporeTowerKilled_Scream_HPP
#define UE4SS_SDK_CameraShake_SporeTowerKilled_Scream_HPP

class UCameraShake_SporeTowerKilled_Scream_C : public UMatineeCameraShake
{
};

#endif
