#ifndef UE4SS_SDK_BP_ChimneyGeyser05_Carved_HPP
#define UE4SS_SDK_BP_ChimneyGeyser05_Carved_HPP

class ABP_ChimneyGeyser05_Carved_C : public ABP_Chimney_Geyser_Carved_Base_C
{
};

#endif
