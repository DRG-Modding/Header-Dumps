#ifndef UE4SS_SDK_DBA_Anniversary_Trophy_HPP
#define UE4SS_SDK_DBA_Anniversary_Trophy_HPP

class ADBA_Anniversary_Trophy_C : public ADebrisDataActor
{
    class UDebrisItemComponent* DebrisItem;
    class USceneComponent* DefaultSceneRoot;

};

#endif
