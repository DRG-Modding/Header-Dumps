namespace ENUM_MutatorWarning {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator4 = 1,
        ENUM_MAX = 2,
    };
}

