namespace DroppodDoorState {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        DroppodDoorState_MAX = 3,
    };
}

