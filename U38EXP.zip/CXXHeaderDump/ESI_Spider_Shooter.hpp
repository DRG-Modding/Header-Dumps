#ifndef UE4SS_SDK_ESI_Spider_Shooter_HPP
#define UE4SS_SDK_ESI_Spider_Shooter_HPP

class AESI_Spider_Shooter_C : public AESI_Spider_Base_C
{
};

#endif
