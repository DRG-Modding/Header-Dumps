#ifndef UE4SS_SDK_ITM_BarGlass_Item_GlyphidSlammer_HPP
#define UE4SS_SDK_ITM_BarGlass_Item_GlyphidSlammer_HPP

class AITM_BarGlass_Item_GlyphidSlammer_C : public AITM_BarGlass_Item_C
{
};

#endif
