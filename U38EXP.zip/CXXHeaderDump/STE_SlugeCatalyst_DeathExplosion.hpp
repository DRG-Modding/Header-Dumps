#ifndef UE4SS_SDK_STE_SlugeCatalyst_DeathExplosion_HPP
#define UE4SS_SDK_STE_SlugeCatalyst_DeathExplosion_HPP

class USTE_SlugeCatalyst_DeathExplosion_C : public UStatusEffect
{
};

#endif
