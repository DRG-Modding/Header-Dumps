#ifndef UE4SS_SDK_BP_CameraDrone_FlareProjectile_HPP
#define UE4SS_SDK_BP_CameraDrone_FlareProjectile_HPP

class ABP_CameraDrone_FlareProjectile_C : public APRJ_FlareGun_Projectile01_C
{
};

#endif
