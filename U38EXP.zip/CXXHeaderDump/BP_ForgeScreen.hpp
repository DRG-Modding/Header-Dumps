#ifndef UE4SS_SDK_BP_ForgeScreen_HPP
#define UE4SS_SDK_BP_ForgeScreen_HPP

class ABP_ForgeScreen_C : public AActor
{
    class UWidgetComponent* Widget;
    class USceneComponent* DefaultSceneRoot;

};

#endif
