#ifndef UE4SS_SDK_STE_PatrolBot_Hacked_HPP
#define UE4SS_SDK_STE_PatrolBot_Hacked_HPP

class USTE_PatrolBot_Hacked_C : public UStatusEffect
{
};

#endif
