#ifndef UE4SS_SDK_STE_Geyser_Lava_HPP
#define UE4SS_SDK_STE_Geyser_Lava_HPP

class USTE_Geyser_Lava_C : public UStatusEffect
{
};

#endif
