#ifndef UE4SS_SDK_STE_SnowStom_Slowdown_Enemies_HPP
#define UE4SS_SDK_STE_SnowStom_Slowdown_Enemies_HPP

class USTE_SnowStom_Slowdown_Enemies_C : public UStatusEffect
{
};

#endif
