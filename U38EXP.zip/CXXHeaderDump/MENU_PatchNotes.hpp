#ifndef UE4SS_SDK_MENU_PatchNotes_HPP
#define UE4SS_SDK_MENU_PatchNotes_HPP

class UMENU_PatchNotes_C : public UWindowWidget
{
    class UITM_SocialMediaButtons_C* ITM_SocialMediaButtons;
    class UUI_PatchNotes_C* UI_PatchNotes;

};

#endif
