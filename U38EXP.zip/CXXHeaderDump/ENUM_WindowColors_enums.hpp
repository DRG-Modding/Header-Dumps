namespace ENUM_WindowColors {
    enum Type {
        NewEnumerator2 = 0,
        NewEnumerator31 = 1,
        NewEnumerator33 = 2,
        NewEnumerator34 = 3,
        NewEnumerator35 = 4,
        NewEnumerator36 = 5,
        ENUM_MAX = 6,
    };
}

