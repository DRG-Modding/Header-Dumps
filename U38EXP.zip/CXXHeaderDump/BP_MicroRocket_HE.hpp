#ifndef UE4SS_SDK_BP_MicroRocket_HE_HPP
#define UE4SS_SDK_BP_MicroRocket_HE_HPP

class ABP_MicroRocket_HE_C : public ABP_MicroRocket_Base_C
{
};

#endif
