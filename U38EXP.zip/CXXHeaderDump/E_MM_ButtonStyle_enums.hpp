namespace E_MM_ButtonStyle {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        E_MM_MAX = 3,
    };
}

