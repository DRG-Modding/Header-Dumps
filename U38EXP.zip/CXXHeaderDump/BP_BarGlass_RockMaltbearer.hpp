#ifndef UE4SS_SDK_BP_BarGlass_RockMaltbearer_HPP
#define UE4SS_SDK_BP_BarGlass_RockMaltbearer_HPP

class ABP_BarGlass_RockMaltbearer_C : public ABP_BarGlass_Standard_C
{
};

#endif
