#ifndef UE4SS_SDK_Loadout_GrenadeProxy_Neurotoxin_HPP
#define UE4SS_SDK_Loadout_GrenadeProxy_Neurotoxin_HPP

class ALoadout_GrenadeProxy_Neurotoxin_C : public ALoadout_GrenadeProxy_Pineapple_C
{
};

#endif
