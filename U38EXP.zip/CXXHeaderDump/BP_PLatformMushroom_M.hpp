#ifndef UE4SS_SDK_BP_PLatformMushroom_M_HPP
#define UE4SS_SDK_BP_PLatformMushroom_M_HPP

class ABP_PLatformMushroom_M_C : public ABP_PlatformMushroom_Base_C
{
    class ULevelGenerationCarverComponent* LevelGenerationCarverStem;

};

#endif
