#ifndef UE4SS_SDK_BP_BarGlass_TunnelRat_HPP
#define UE4SS_SDK_BP_BarGlass_TunnelRat_HPP

class ABP_BarGlass_TunnelRat_C : public ABP_BarGlass_Standard_C
{
};

#endif
