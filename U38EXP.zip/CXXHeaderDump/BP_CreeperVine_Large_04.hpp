#ifndef UE4SS_SDK_BP_CreeperVine_Large_04_HPP
#define UE4SS_SDK_BP_CreeperVine_Large_04_HPP

class ABP_CreeperVine_Large_04_C : public ABP_CreeperVine_Base_C
{
};

#endif
