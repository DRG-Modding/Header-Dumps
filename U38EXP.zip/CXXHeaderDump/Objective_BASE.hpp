#ifndef UE4SS_SDK_Objective_BASE_HPP
#define UE4SS_SDK_Objective_BASE_HPP

class UObjective_BASE_C : public UUserWidget
{
    FLinearColor CompletedColor;

    void InitObjective(class UObjective* Objective);
};

#endif
