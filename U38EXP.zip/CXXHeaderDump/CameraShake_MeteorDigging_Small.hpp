#ifndef UE4SS_SDK_CameraShake_MeteorDigging_Small_HPP
#define UE4SS_SDK_CameraShake_MeteorDigging_Small_HPP

class UCameraShake_MeteorDigging_Small_C : public UMatineeCameraShake
{
};

#endif
