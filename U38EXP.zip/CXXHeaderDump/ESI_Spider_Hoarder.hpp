#ifndef UE4SS_SDK_ESI_Spider_Hoarder_HPP
#define UE4SS_SDK_ESI_Spider_Hoarder_HPP

class AESI_Spider_Hoarder_C : public AESI_Spider_Base_C
{
    class USkeletalMeshComponent* SK_HoarderBack_A;
    class USkeletalMeshComponent* SK_HoarderHead_A;

};

#endif
