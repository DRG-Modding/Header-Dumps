#ifndef UE4SS_SDK_BP_Endscreen_Drone_HPP
#define UE4SS_SDK_BP_Endscreen_Drone_HPP

class ABP_Endscreen_Drone_C : public AActor
{
    class USkeletalMeshComponent* SkeletalMesh;
    class USceneComponent* DefaultSceneRoot;

};

#endif
