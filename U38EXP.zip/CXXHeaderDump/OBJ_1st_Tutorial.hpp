#ifndef UE4SS_SDK_OBJ_1st_Tutorial_HPP
#define UE4SS_SDK_OBJ_1st_Tutorial_HPP

class UOBJ_1st_Tutorial_C : public UOBJ_Extraction_Base_C
{

    bool IsTutorialObjective();
};

#endif
