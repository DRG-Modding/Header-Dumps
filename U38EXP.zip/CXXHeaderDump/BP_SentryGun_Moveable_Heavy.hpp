#ifndef UE4SS_SDK_BP_SentryGun_Moveable_Heavy_HPP
#define UE4SS_SDK_BP_SentryGun_Moveable_Heavy_HPP

class ABP_SentryGun_Moveable_Heavy_C : public ABP_SentryGun_Moveable_C
{
};

#endif
