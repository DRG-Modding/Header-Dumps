#ifndef UE4SS_SDK_ITM_BarGlass_Item_BurningLove_HPP
#define UE4SS_SDK_ITM_BarGlass_Item_BurningLove_HPP

class AITM_BarGlass_Item_BurningLove_C : public AITM_BarGlass_Item_C
{
};

#endif
