#ifndef UE4SS_SDK_ENE_JellyBreeder_Normal_HPP
#define UE4SS_SDK_ENE_JellyBreeder_Normal_HPP

class AENE_JellyBreeder_Normal_C : public AENE_JellyBreeder_Base_C
{
};

#endif
