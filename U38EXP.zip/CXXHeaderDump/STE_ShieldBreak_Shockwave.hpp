#ifndef UE4SS_SDK_STE_ShieldBreak_Shockwave_HPP
#define UE4SS_SDK_STE_ShieldBreak_Shockwave_HPP

class USTE_ShieldBreak_Shockwave_C : public UStatusEffect
{
};

#endif
