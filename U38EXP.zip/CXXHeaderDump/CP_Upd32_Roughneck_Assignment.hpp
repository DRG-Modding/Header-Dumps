#ifndef UE4SS_SDK_CP_Upd32_Roughneck_Assignment_HPP
#define UE4SS_SDK_CP_Upd32_Roughneck_Assignment_HPP

class UCP_Upd32_Roughneck_Assignment_C : public UCampaign
{
};

#endif
