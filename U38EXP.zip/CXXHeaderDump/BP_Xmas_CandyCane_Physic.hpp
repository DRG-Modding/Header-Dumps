#ifndef UE4SS_SDK_BP_Xmas_CandyCane_Physic_HPP
#define UE4SS_SDK_BP_Xmas_CandyCane_Physic_HPP

class ABP_Xmas_CandyCane_Physic_C : public AActor
{
    class USimpleObjectInfoComponent* SimpleObjectInfo;
    class USkeletalMeshComponent* SK_Xmas_CandyCane_01;
    class UBoxComponent* Box;

};

#endif
