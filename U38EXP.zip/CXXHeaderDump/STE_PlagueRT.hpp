#ifndef UE4SS_SDK_STE_PlagueRT_HPP
#define UE4SS_SDK_STE_PlagueRT_HPP

class USTE_PlagueRT_C : public UStatusEffect
{
};

#endif
