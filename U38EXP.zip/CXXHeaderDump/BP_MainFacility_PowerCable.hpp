#ifndef UE4SS_SDK_BP_MainFacility_PowerCable_HPP
#define UE4SS_SDK_BP_MainFacility_PowerCable_HPP

class ABP_MainFacility_PowerCable_C : public AFacilityGeneratorLine
{
    class USimpleObjectInfoComponent* SimpleObjectInfo;

};

#endif
