#ifndef UE4SS_SDK_ITM_Flare_Small_Driller_HPP
#define UE4SS_SDK_ITM_Flare_Small_Driller_HPP

class AITM_Flare_Small_Driller_C : public AITM_Flare_Small_C
{
};

#endif
