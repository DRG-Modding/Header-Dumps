#ifndef UE4SS_SDK_BP_WormPlant_Animated_Magma_HPP
#define UE4SS_SDK_BP_WormPlant_Animated_Magma_HPP

class ABP_WormPlant_Animated_Magma_C : public ABP_AnimatedFoliage_Base_C
{
};

#endif
