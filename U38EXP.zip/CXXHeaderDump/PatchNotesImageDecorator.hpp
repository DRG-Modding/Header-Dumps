#ifndef UE4SS_SDK_PatchNotesImageDecorator_HPP
#define UE4SS_SDK_PatchNotesImageDecorator_HPP

class UPatchNotesImageDecorator_C : public URichTextBlockImageDecorator
{
};

#endif
