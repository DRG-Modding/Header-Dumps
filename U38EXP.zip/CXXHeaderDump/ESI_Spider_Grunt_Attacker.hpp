#ifndef UE4SS_SDK_ESI_Spider_Grunt_Attacker_HPP
#define UE4SS_SDK_ESI_Spider_Grunt_Attacker_HPP

class AESI_Spider_Grunt_Attacker_C : public AESI_Spider_Base_C
{
};

#endif
