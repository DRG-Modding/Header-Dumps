#ifndef UE4SS_SDK_PRW_RecallableSentryGun_HPP
#define UE4SS_SDK_PRW_RecallableSentryGun_HPP

class APRW_RecallableSentryGun_C : public AActor
{
    class USkeletalMeshComponent* SkeletalMesh;
    class USceneComponent* DefaultSceneRoot;

};

#endif
