#ifndef UE4SS_SDK_BP_RockFormation_2Platuaes_B_HPP
#define UE4SS_SDK_BP_RockFormation_2Platuaes_B_HPP

class ABP_RockFormation_2Platuaes_B_C : public ABP_IceFormation_Base_C
{
    class UStaticMeshComponent* Ice_Formation_A;

};

#endif
