#ifndef UE4SS_SDK_PRW_AssaultRifle_HPP
#define UE4SS_SDK_PRW_AssaultRifle_HPP

class APRW_AssaultRifle_C : public AItemPreviewActor
{
    class UStaticMeshComponent* Mag;
    class USkeletalMeshComponent* SkeletalMesh;
    class USceneComponent* DefaultSceneRoot;

};

#endif
