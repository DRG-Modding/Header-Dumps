#ifndef UE4SS_SDK_ESI_JellyBreeder_RockpoxPlague_HPP
#define UE4SS_SDK_ESI_JellyBreeder_RockpoxPlague_HPP

class AESI_JellyBreeder_RockpoxPlague_C : public AEnemyShowroomItem
{
    class UStaticMeshComponent* InfectionPoint2;
    class UStaticMeshComponent* InfectionPoint3;
    class UStaticMeshComponent* InfectionPoint1;
    class UStaticMeshComponent* InfectionPoint8;
    class UStaticMeshComponent* InfectionPoint7;
    class UStaticMeshComponent* InfectionPoint5;
    class UStaticMeshComponent* InfectionPoint4;
    class USkeletalMeshComponent* SkeletalMesh;
    class USceneComponent* DefaultSceneRoot;

};

#endif
