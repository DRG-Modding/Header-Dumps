#ifndef UE4SS_SDK_STE_Grenade_Pheromone_HPP
#define UE4SS_SDK_STE_Grenade_Pheromone_HPP

class USTE_Grenade_Pheromone_C : public UStatusEffect
{
};

#endif
