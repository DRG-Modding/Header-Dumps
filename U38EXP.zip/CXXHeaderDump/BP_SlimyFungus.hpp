#ifndef UE4SS_SDK_BP_SlimyFungus_HPP
#define UE4SS_SDK_BP_SlimyFungus_HPP

class ABP_SlimyFungus_C : public ABP_PassiveFoliage_Base_C
{
};

#endif
