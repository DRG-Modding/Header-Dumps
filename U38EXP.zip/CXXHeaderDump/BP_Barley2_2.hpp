#ifndef UE4SS_SDK_BP_Barley2_2_HPP
#define UE4SS_SDK_BP_Barley2_2_HPP

class ABP_Barley2_2_C : public ABP_Collectible_Barley_B2_C
{
};

#endif
