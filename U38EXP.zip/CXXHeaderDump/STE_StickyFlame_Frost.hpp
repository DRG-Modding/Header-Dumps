#ifndef UE4SS_SDK_STE_StickyFlame_Frost_HPP
#define UE4SS_SDK_STE_StickyFlame_Frost_HPP

class USTE_StickyFlame_Frost_C : public UStatusEffect
{
};

#endif
