#ifndef UE4SS_SDK_BP_Phys_Hammer_HPP
#define UE4SS_SDK_BP_Phys_Hammer_HPP

class ABP_Phys_Hammer_C : public ABP_Phys_Crate_F_C
{
};

#endif
