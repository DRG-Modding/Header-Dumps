#ifndef UE4SS_SDK_PRW_Armor_Scout_HPP
#define UE4SS_SDK_PRW_Armor_Scout_HPP

class APRW_Armor_Scout_C : public APRW_Armor_Base_C
{
};

#endif
