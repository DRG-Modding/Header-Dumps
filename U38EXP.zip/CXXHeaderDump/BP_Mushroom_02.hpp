#ifndef UE4SS_SDK_BP_Mushroom_02_HPP
#define UE4SS_SDK_BP_Mushroom_02_HPP

class ABP_Mushroom_02_C : public ABP_Mushroom_Base_C
{
};

#endif
