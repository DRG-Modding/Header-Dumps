#ifndef UE4SS_SDK_ENE_StabberVines2_HPP
#define UE4SS_SDK_ENE_StabberVines2_HPP

class AENE_StabberVines2_C : public AENE_StabberVines_C
{
};

#endif
