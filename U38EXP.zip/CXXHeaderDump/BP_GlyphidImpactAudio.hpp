#ifndef UE4SS_SDK_BP_GlyphidImpactAudio_HPP
#define UE4SS_SDK_BP_GlyphidImpactAudio_HPP

class UBP_GlyphidImpactAudio_C : public UImpactAudioComponent
{
};

#endif
