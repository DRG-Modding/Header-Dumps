#ifndef UE4SS_SDK_STE_InsectDoT_HPP
#define UE4SS_SDK_STE_InsectDoT_HPP

class USTE_InsectDoT_C : public UStatusEffect
{
};

#endif
