#ifndef UE4SS_SDK_BP_SmallMeteorSpawner_HPP
#define UE4SS_SDK_BP_SmallMeteorSpawner_HPP

class ABP_SmallMeteorSpawner_C : public APlagueMeteorSpawner
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
