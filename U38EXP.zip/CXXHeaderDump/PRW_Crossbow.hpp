#ifndef UE4SS_SDK_PRW_Crossbow_HPP
#define UE4SS_SDK_PRW_Crossbow_HPP

class APRW_Crossbow_C : public AItemPreviewActor
{
    class UStaticMeshComponent* Arrow;
    class USkeletalMeshComponent* SkeletalMesh;
    class USceneComponent* DefaultSceneRoot;

};

#endif
