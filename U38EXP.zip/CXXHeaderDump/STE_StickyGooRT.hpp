#ifndef UE4SS_SDK_STE_StickyGooRT_HPP
#define UE4SS_SDK_STE_StickyGooRT_HPP

class USTE_StickyGooRT_C : public UStatusEffect
{
};

#endif
