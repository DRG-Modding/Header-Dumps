#ifndef UE4SS_SDK_DBA_Oktoberfest_HPP
#define UE4SS_SDK_DBA_Oktoberfest_HPP

class ADBA_Oktoberfest_C : public ADebrisDataActor
{
    class UDebrisItemComponent* DebrisItem;
    class USceneComponent* DefaultSceneRoot;

};

#endif
