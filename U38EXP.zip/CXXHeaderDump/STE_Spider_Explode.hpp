#ifndef UE4SS_SDK_STE_Spider_Explode_HPP
#define UE4SS_SDK_STE_Spider_Explode_HPP

class USTE_Spider_Explode_C : public UStatusEffect
{
};

#endif
