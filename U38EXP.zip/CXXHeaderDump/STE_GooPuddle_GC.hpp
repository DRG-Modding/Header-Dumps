#ifndef UE4SS_SDK_STE_GooPuddle_GC_HPP
#define UE4SS_SDK_STE_GooPuddle_GC_HPP

class USTE_GooPuddle_GC_C : public UStatusEffect
{
};

#endif
