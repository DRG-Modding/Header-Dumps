#ifndef UE4SS_SDK_BP_SaltFormation_Large_1_HPP
#define UE4SS_SDK_BP_SaltFormation_Large_1_HPP

class ABP_SaltFormation_Large_1_C : public ABP_SaltFormations_Base_C
{
};

#endif
