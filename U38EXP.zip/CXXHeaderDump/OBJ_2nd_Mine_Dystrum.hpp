#ifndef UE4SS_SDK_OBJ_2nd_Mine_Dystrum_HPP
#define UE4SS_SDK_OBJ_2nd_Mine_Dystrum_HPP

class UOBJ_2nd_Mine_Dystrum_C : public UOBJ_Extraction_Base_C
{
};

#endif
