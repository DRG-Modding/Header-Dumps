#ifndef UE4SS_SDK_STE_Boss_Heavy_Enraged_HPP
#define UE4SS_SDK_STE_Boss_Heavy_Enraged_HPP

class USTE_Boss_Heavy_Enraged_C : public UStatusEffect
{
};

#endif
