#ifndef UE4SS_SDK_CP_PrestigeAssignment_PickaxeHunt_70__HPP
#define UE4SS_SDK_CP_PrestigeAssignment_PickaxeHunt_70__HPP

class UCP_PrestigeAssignment_PickaxeHunt_70__C : public UCampaign
{
};

#endif
