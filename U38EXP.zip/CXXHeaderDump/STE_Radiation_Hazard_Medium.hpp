#ifndef UE4SS_SDK_STE_Radiation_Hazard_Medium_HPP
#define UE4SS_SDK_STE_Radiation_Hazard_Medium_HPP

class USTE_Radiation_Hazard_Medium_C : public UStatusEffect
{
};

#endif
