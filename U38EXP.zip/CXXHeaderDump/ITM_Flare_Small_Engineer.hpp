#ifndef UE4SS_SDK_ITM_Flare_Small_Engineer_HPP
#define UE4SS_SDK_ITM_Flare_Small_Engineer_HPP

class AITM_Flare_Small_Engineer_C : public AITM_Flare_Small_C
{
};

#endif
