#ifndef UE4SS_SDK_BP_SentryItem_PlaceMarker_Heavy_HPP
#define UE4SS_SDK_BP_SentryItem_PlaceMarker_Heavy_HPP

class ABP_SentryItem_PlaceMarker_Heavy_C : public ABP_SentryItem_PlaceMarker_C
{
};

#endif
