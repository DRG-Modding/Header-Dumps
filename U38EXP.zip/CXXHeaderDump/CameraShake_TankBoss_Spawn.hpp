#ifndef UE4SS_SDK_CameraShake_TankBoss_Spawn_HPP
#define UE4SS_SDK_CameraShake_TankBoss_Spawn_HPP

class UCameraShake_TankBoss_Spawn_C : public UMatineeCameraShake
{
};

#endif
