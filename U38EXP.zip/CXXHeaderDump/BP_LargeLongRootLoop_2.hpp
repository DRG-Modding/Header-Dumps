#ifndef UE4SS_SDK_BP_LargeLongRootLoop_2_HPP
#define UE4SS_SDK_BP_LargeLongRootLoop_2_HPP

class ABP_LargeLongRootLoop_2_C : public ABP_HugeRoots_Base_C
{
};

#endif
