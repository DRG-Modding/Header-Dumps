#ifndef UE4SS_SDK_CP_WPN_ElectricSMG_HPP
#define UE4SS_SDK_CP_WPN_ElectricSMG_HPP

class UCP_WPN_ElectricSMG_C : public UCampaign
{
};

#endif
