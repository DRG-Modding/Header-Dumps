#ifndef UE4SS_SDK_BP_LargeHollowLog_1_HPP
#define UE4SS_SDK_BP_LargeHollowLog_1_HPP

class ABP_LargeHollowLog_1_C : public ABP_HugeRoots_Base_C
{
};

#endif
