#ifndef UE4SS_SDK_STE_BeastMaster_HPP
#define UE4SS_SDK_STE_BeastMaster_HPP

class USTE_BeastMaster_C : public UStatusEffect
{
};

#endif
