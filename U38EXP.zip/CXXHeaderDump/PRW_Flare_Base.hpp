#ifndef UE4SS_SDK_PRW_Flare_Base_HPP
#define UE4SS_SDK_PRW_Flare_Base_HPP

class APRW_Flare_Base_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* DefaultSceneRoot;

};

#endif
