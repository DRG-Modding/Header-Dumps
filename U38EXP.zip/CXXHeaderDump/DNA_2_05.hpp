#ifndef UE4SS_SDK_DNA_2_05_HPP
#define UE4SS_SDK_DNA_2_05_HPP

class UDNA_2_05_C : public UMissionDNA
{
};

#endif
