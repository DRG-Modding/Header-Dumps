#ifndef UE4SS_SDK_BP_WormPlant_Animated_Radioactive_HPP
#define UE4SS_SDK_BP_WormPlant_Animated_Radioactive_HPP

class ABP_WormPlant_Animated_Radioactive_C : public ABP_AnimatedFoliage_Base_C
{
};

#endif
