namespace WeatherState {
    enum Type {
        NewEnumerator4 = 0,
        NewEnumerator0 = 1,
        NewEnumerator1 = 2,
        NewEnumerator2 = 3,
        WeatherState_MAX = 4,
    };
}

