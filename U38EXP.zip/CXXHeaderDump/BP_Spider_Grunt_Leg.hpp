#ifndef UE4SS_SDK_BP_Spider_Grunt_Leg_HPP
#define UE4SS_SDK_BP_Spider_Grunt_Leg_HPP

class ABP_Spider_Grunt_Leg_C : public ABP_Spider_Leg_Base_C
{
};

#endif
