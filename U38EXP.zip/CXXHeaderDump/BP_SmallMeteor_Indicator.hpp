#ifndef UE4SS_SDK_BP_SmallMeteor_Indicator_HPP
#define UE4SS_SDK_BP_SmallMeteor_Indicator_HPP

class ABP_SmallMeteor_Indicator_C : public AImpactIndicator
{
    class UStaticMeshComponent* OuterIndicator;

};

#endif
