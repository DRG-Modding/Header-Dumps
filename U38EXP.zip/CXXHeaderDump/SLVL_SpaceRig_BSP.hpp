#ifndef UE4SS_SDK_SLVL_SpaceRig_BSP_HPP
#define UE4SS_SDK_SLVL_SpaceRig_BSP_HPP

class ASLVL_SpaceRig_BSP_C : public ALevelScriptActor
{
};

#endif
