#ifndef UE4SS_SDK_ENE_Bomber_Ice_HPP
#define UE4SS_SDK_ENE_Bomber_Ice_HPP

class AENE_Bomber_Ice_C : public AENE_Bomber_Child_C
{
};

#endif
