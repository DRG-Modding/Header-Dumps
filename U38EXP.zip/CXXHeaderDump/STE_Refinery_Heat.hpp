#ifndef UE4SS_SDK_STE_Refinery_Heat_HPP
#define UE4SS_SDK_STE_Refinery_Heat_HPP

class USTE_Refinery_Heat_C : public UStatusEffect
{
};

#endif
