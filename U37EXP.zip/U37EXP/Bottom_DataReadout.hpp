#ifndef UE4SS_SDK_Bottom_DataReadout_HPP
#define UE4SS_SDK_Bottom_DataReadout_HPP

class UBottom_DataReadout_C : public UUserWidget
{
    class UBasic_BG_CutCorner_C* Basic_BG_Window;
    class UImage* Image_47;

};

#endif
