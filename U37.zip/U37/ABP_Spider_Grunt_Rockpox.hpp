#ifndef UE4SS_SDK_ABP_Spider_Grunt_Rockpox_HPP
#define UE4SS_SDK_ABP_Spider_Grunt_Rockpox_HPP

class UABP_Spider_Grunt_Rockpox_C : public UABP_Spider_Grunt_C
{
};

#endif
