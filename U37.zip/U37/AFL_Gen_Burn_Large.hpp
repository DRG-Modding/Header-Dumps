#ifndef UE4SS_SDK_AFL_Gen_Burn_Large_HPP
#define UE4SS_SDK_AFL_Gen_Burn_Large_HPP

class UAFL_Gen_Burn_Large_C : public UBurningAfflictionEffect
{
};

#endif
