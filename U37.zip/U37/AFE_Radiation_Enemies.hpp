#ifndef UE4SS_SDK_AFE_Radiation_Enemies_HPP
#define UE4SS_SDK_AFE_Radiation_Enemies_HPP

class UAFE_Radiation_Enemies_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
