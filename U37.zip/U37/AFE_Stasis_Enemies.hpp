#ifndef UE4SS_SDK_AFE_Stasis_Enemies_HPP
#define UE4SS_SDK_AFE_Stasis_Enemies_HPP

class UAFE_Stasis_Enemies_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
