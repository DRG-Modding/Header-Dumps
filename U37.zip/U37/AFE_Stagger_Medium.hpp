#ifndef UE4SS_SDK_AFE_Stagger_Medium_HPP
#define UE4SS_SDK_AFE_Stagger_Medium_HPP

class UAFE_Stagger_Medium_C : public UStaggeredAfflictionEffect
{
};

#endif
