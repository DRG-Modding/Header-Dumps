#ifndef UE4SS_SDK_AIC_FacilityTurret_Sniper_HPP
#define UE4SS_SDK_AIC_FacilityTurret_Sniper_HPP

class AAIC_FacilityTurret_Sniper_C : public AAIC_FacilityTurret_Burst_C
{
};

#endif
