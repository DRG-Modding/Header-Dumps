#ifndef UE4SS_SDK_Basic_BG_Window_W_Header_HPP
#define UE4SS_SDK_Basic_BG_Window_W_Header_HPP

class UBasic_BG_Window_W_Header_C : public UUserWidget
{
    class UBasic_BG_CutCorner_C* Basic_BG_Window;
    class UBasic_BG_CutCorner_C* Basic_BG_Window_65;
    class UNamedSlot* NamedSlot_65;

};

#endif
