#ifndef UE4SS_SDK_AFE_TP_Fire_HPP
#define UE4SS_SDK_AFE_TP_Fire_HPP

class UAFE_TP_Fire_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
