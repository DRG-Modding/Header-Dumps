#ifndef UE4SS_SDK_BG_Window_Outline_4px_HPP
#define UE4SS_SDK_BG_Window_Outline_4px_HPP

class UBG_Window_Outline_4px_C : public UUserWidget
{
    class UImage* Image_62;

};

#endif
