#ifndef UE4SS_SDK_Basic_Hover_Bracket_Small_HPP
#define UE4SS_SDK_Basic_Hover_Bracket_Small_HPP

class UBasic_Hover_Bracket_Small_C : public UUserWidget
{
    class UImage* Image_699;
    class UImage* Image_763;
    class UImage* Image_910;

};

#endif
