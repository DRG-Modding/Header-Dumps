#ifndef UE4SS_SDK_AFE_FP_SnowStorm_HPP
#define UE4SS_SDK_AFE_FP_SnowStorm_HPP

class UAFE_FP_SnowStorm_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
