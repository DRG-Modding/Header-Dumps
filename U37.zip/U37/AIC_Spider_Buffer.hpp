#ifndef UE4SS_SDK_AIC_Spider_Buffer_HPP
#define UE4SS_SDK_AIC_Spider_Buffer_HPP

class AAIC_Spider_Buffer_C : public AAIC_Spider_C
{
};

#endif
