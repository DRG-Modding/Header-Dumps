#ifndef UE4SS_SDK_AnimatedStaticOverlay_WithScanlines_HPP
#define UE4SS_SDK_AnimatedStaticOverlay_WithScanlines_HPP

class UAnimatedStaticOverlay_WithScanlines_C : public UUserWidget
{
    class UImage* BorderGradient;
    class UImage* Static;

};

#endif
