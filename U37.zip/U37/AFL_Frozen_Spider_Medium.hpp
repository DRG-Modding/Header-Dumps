#ifndef UE4SS_SDK_AFL_Frozen_Spider_Medium_HPP
#define UE4SS_SDK_AFL_Frozen_Spider_Medium_HPP

class UAFL_Frozen_Spider_Medium_C : public UScalingMeshAfflictionEffect
{
};

#endif
