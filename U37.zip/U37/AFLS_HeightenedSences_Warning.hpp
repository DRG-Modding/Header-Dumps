#ifndef UE4SS_SDK_AFLS_HeightenedSences_Warning_HPP
#define UE4SS_SDK_AFLS_HeightenedSences_Warning_HPP

class UAFLS_HeightenedSences_Warning_C : public USoundAfflictionEffect
{
};

#endif
