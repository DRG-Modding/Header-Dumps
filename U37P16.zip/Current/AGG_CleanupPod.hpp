#ifndef UE4SS_SDK_AGG_CleanupPod_HPP
#define UE4SS_SDK_AGG_CleanupPod_HPP

class UAGG_CleanupPod_C : public UItemPlacerAggregator
{
};

#endif
