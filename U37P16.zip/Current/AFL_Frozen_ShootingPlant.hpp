#ifndef UE4SS_SDK_AFL_Frozen_ShootingPlant_HPP
#define UE4SS_SDK_AFL_Frozen_ShootingPlant_HPP

class UAFL_Frozen_ShootingPlant_C : public UScalingMeshAfflictionEffect
{
};

#endif
