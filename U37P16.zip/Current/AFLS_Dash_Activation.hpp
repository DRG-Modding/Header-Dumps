#ifndef UE4SS_SDK_AFLS_Dash_Activation_HPP
#define UE4SS_SDK_AFLS_Dash_Activation_HPP

class UAFLS_Dash_Activation_C : public USoundAfflictionEffect
{
};

#endif
