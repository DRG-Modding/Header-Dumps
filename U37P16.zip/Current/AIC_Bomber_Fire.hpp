#ifndef UE4SS_SDK_AIC_Bomber_Fire_HPP
#define UE4SS_SDK_AIC_Bomber_Fire_HPP

class AAIC_Bomber_Fire_C : public AFSDFlyingBugController
{
};

#endif
