#ifndef UE4SS_SDK_AFLS_IronWill_HPP
#define UE4SS_SDK_AFLS_IronWill_HPP

class UAFLS_IronWill_C : public USoundAfflictionEffect
{
};

#endif
