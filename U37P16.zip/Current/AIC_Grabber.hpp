#ifndef UE4SS_SDK_AIC_Grabber_HPP
#define UE4SS_SDK_AIC_Grabber_HPP

class AAIC_Grabber_C : public AFSDFlyingBugController
{
};

#endif
