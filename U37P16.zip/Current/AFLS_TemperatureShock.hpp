#ifndef UE4SS_SDK_AFLS_TemperatureShock_HPP
#define UE4SS_SDK_AFLS_TemperatureShock_HPP

class UAFLS_TemperatureShock_C : public USoundAfflictionEffect
{
};

#endif
