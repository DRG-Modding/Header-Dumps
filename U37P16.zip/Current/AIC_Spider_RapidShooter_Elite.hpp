#ifndef UE4SS_SDK_AIC_Spider_RapidShooter_Elite_HPP
#define UE4SS_SDK_AIC_Spider_RapidShooter_Elite_HPP

class AAIC_Spider_RapidShooter_Elite_C : public AAIC_Spider_RapidShooter_C
{
};

#endif
