#ifndef UE4SS_SDK_AIC_Spider_Shooter_Queen_HPP
#define UE4SS_SDK_AIC_Spider_Shooter_Queen_HPP

class AAIC_Spider_Shooter_Queen_C : public AAIC_Spider_C
{
};

#endif
