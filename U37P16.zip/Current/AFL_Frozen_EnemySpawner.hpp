#ifndef UE4SS_SDK_AFL_Frozen_EnemySpawner_HPP
#define UE4SS_SDK_AFL_Frozen_EnemySpawner_HPP

class UAFL_Frozen_EnemySpawner_C : public UScalingMeshAfflictionEffect
{
};

#endif
