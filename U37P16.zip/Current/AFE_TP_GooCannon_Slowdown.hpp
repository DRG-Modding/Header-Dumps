#ifndef UE4SS_SDK_AFE_TP_GooCannon_Slowdown_HPP
#define UE4SS_SDK_AFE_TP_GooCannon_Slowdown_HPP

class UAFE_TP_GooCannon_Slowdown_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
