#ifndef UE4SS_SDK_AIC_Spider_Tank_Normal_Infection_HPP
#define UE4SS_SDK_AIC_Spider_Tank_Normal_Infection_HPP

class AAIC_Spider_Tank_Normal_Infection_C : public AAIC_Spider_Tank_Normal_C
{
};

#endif
