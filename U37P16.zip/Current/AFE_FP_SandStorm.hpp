#ifndef UE4SS_SDK_AFE_FP_SandStorm_HPP
#define UE4SS_SDK_AFE_FP_SandStorm_HPP

class UAFE_FP_SandStorm_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
