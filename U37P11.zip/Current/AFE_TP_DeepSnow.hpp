#ifndef UE4SS_SDK_AFE_TP_DeepSnow_HPP
#define UE4SS_SDK_AFE_TP_DeepSnow_HPP

class UAFE_TP_DeepSnow_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
