#ifndef UE4SS_SDK_Bar_Glass_Physics_SkullCrusher_HPP
#define UE4SS_SDK_Bar_Glass_Physics_SkullCrusher_HPP

class ABar_Glass_Physics_SkullCrusher_C : public ABar_Glass_Physics_C
{
};

#endif
