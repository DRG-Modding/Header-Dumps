#ifndef UE4SS_SDK_ABP_SpiderHoarder_HPP
#define UE4SS_SDK_ABP_SpiderHoarder_HPP

class UABP_SpiderHoarder_C : public UABP_Spider_Grunt_C
{
};

#endif
