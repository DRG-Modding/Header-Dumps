#ifndef UE4SS_SDK_AFL_Gen_Burn_Medium_HPP
#define UE4SS_SDK_AFL_Gen_Burn_Medium_HPP

class UAFL_Gen_Burn_Medium_C : public UBurningAfflictionEffect
{
};

#endif
