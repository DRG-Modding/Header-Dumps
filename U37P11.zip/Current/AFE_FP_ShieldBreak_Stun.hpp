#ifndef UE4SS_SDK_AFE_FP_ShieldBreak_Stun_HPP
#define UE4SS_SDK_AFE_FP_ShieldBreak_Stun_HPP

class UAFE_FP_ShieldBreak_Stun_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
