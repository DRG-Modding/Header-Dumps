#ifndef UE4SS_SDK_AFL_Infected_Player_HPP
#define UE4SS_SDK_AFL_Infected_Player_HPP

class UAFL_Infected_Player_C : public UScalingMeshAfflictionEffect
{
};

#endif
