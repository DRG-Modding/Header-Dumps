#ifndef UE4SS_SDK_BP_Phys_Barrel_Hoop_HPP
#define UE4SS_SDK_BP_Phys_Barrel_Hoop_HPP

class ABP_Phys_Barrel_Hoop_C : public ABP_Phys_Barrel01_C
{
};

#endif
