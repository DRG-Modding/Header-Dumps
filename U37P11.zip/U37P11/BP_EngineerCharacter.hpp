#ifndef UE4SS_SDK_BP_EngineerCharacter_HPP
#define UE4SS_SDK_BP_EngineerCharacter_HPP

class ABP_EngineerCharacter_C : public ABP_PlayerCharacter_C
{
};

#endif
