#ifndef UE4SS_SDK_BP_ExplosiveEnemiesDamageSmall_HPP
#define UE4SS_SDK_BP_ExplosiveEnemiesDamageSmall_HPP

class UBP_ExplosiveEnemiesDamageSmall_C : public UDamageComponent
{
};

#endif
