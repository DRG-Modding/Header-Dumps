#ifndef UE4SS_SDK_BP_BarGlass_SlayerStout_HPP
#define UE4SS_SDK_BP_BarGlass_SlayerStout_HPP

class ABP_BarGlass_SlayerStout_C : public ABP_BarGlass_Standard_C
{
};

#endif
