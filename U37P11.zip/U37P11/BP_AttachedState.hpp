#ifndef UE4SS_SDK_BP_AttachedState_HPP
#define UE4SS_SDK_BP_AttachedState_HPP

class UBP_AttachedState_C : public UAttachedStateComponent
{
};

#endif
