#ifndef UE4SS_SDK_BP_IconGenerationManager_HPP
#define UE4SS_SDK_BP_IconGenerationManager_HPP

class UBP_IconGenerationManager_C : public UIconGenerationManager
{
};

#endif
