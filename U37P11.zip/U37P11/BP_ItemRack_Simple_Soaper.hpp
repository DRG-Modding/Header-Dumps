#ifndef UE4SS_SDK_BP_ItemRack_Simple_Soaper_HPP
#define UE4SS_SDK_BP_ItemRack_Simple_Soaper_HPP

class ABP_ItemRack_Simple_Soaper_C : public ABP_ItemRack_Simple_C
{
};

#endif
