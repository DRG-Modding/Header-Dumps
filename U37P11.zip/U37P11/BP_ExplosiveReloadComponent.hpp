#ifndef UE4SS_SDK_BP_ExplosiveReloadComponent_HPP
#define UE4SS_SDK_BP_ExplosiveReloadComponent_HPP

class UBP_ExplosiveReloadComponent_C : public UWeaponHitCounterComponent
{
};

#endif
