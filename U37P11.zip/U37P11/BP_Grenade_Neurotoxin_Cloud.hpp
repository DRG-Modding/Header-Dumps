#ifndef UE4SS_SDK_BP_Grenade_Neurotoxin_Cloud_HPP
#define UE4SS_SDK_BP_Grenade_Neurotoxin_Cloud_HPP

class ABP_Grenade_Neurotoxin_Cloud_C : public ABP_Damage_Cloud_Flamable_Base_C
{
};

#endif
