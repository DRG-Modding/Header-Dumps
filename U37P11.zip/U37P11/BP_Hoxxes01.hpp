#ifndef UE4SS_SDK_BP_Hoxxes01_HPP
#define UE4SS_SDK_BP_Hoxxes01_HPP

class ABP_Hoxxes01_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;
    class UStaticMeshComponent* SM_Hoxxes_Part73;
    class UStaticMeshComponent* SM_Hoxxes_Part71;
    class UStaticMeshComponent* SM_Hoxxes_Part70;
    class UStaticMeshComponent* SM_Hoxxes_Part69;
    class UStaticMeshComponent* SM_Hoxxes_Part68;
    class UStaticMeshComponent* SM_Hoxxes_Part67;
    class UStaticMeshComponent* SM_Hoxxes_Part66;
    class UStaticMeshComponent* SM_Hoxxes_Part65;
    class UStaticMeshComponent* SM_Hoxxes_Part64;
    class UStaticMeshComponent* SM_Hoxxes_Part63;
    class UStaticMeshComponent* SM_Hoxxes_Part62;
    class UStaticMeshComponent* SM_Hoxxes_Part58;
    class UStaticMeshComponent* SM_Hoxxes_Part57;
    class UStaticMeshComponent* SM_Hoxxes_Part56;
    class UStaticMeshComponent* SM_Hoxxes_Part55;
    class UStaticMeshComponent* SM_Hoxxes_Part54;
    class UStaticMeshComponent* SM_Hoxxes_Part53;
    class UStaticMeshComponent* SM_Hoxxes_Part52;
    class UStaticMeshComponent* SM_Hoxxes_Part51;
    class UStaticMeshComponent* SM_Hoxxes_Part50;
    class UStaticMeshComponent* SM_Hoxxes_Part49;
    class UStaticMeshComponent* SM_Hoxxes_Part48;
    class UStaticMeshComponent* SM_Hoxxes_Part47;
    class UStaticMeshComponent* SM_Hoxxes_Part46;
    class UStaticMeshComponent* SM_Hoxxes_Part45;
    class UStaticMeshComponent* SM_Hoxxes_Part44;
    class UStaticMeshComponent* SM_Hoxxes_Part43;
    class UStaticMeshComponent* SM_Hoxxes_Part42;
    class UStaticMeshComponent* SM_Hoxxes_Part41;
    class UStaticMeshComponent* SM_Hoxxes_Part40;
    class UStaticMeshComponent* SM_Hoxxes_Part39;
    class UStaticMeshComponent* SM_Hoxxes_Part38;
    class UStaticMeshComponent* SM_Hoxxes_Part37;
    class UStaticMeshComponent* SM_Hoxxes_Part36;
    class UStaticMeshComponent* SM_Hoxxes_Part72;
    class UStaticMeshComponent* SM_Hoxxes_Part34;
    class UStaticMeshComponent* SM_Hoxxes_Part33;
    class UStaticMeshComponent* SM_Hoxxes_Part32;
    class UStaticMeshComponent* SM_Hoxxes_Part31;
    class UStaticMeshComponent* SM_Hoxxes_Part30;
    class UStaticMeshComponent* SM_Hoxxes_Part29;
    class UStaticMeshComponent* SM_Hoxxes_Part28;
    class UStaticMeshComponent* SM_Hoxxes_Part27;
    class UStaticMeshComponent* SM_Hoxxes_Part26;
    class UStaticMeshComponent* SM_Hoxxes_Part25;
    class UStaticMeshComponent* SM_Hoxxes_Part24;
    class UStaticMeshComponent* SM_Hoxxes_Part23;
    class UStaticMeshComponent* SM_Hoxxes_Part22;
    class UStaticMeshComponent* SM_Hoxxes_Part21;
    class UStaticMeshComponent* SM_Hoxxes_Part20;
    class UStaticMeshComponent* SM_Hoxxes_Part19;
    class UStaticMeshComponent* SM_Hoxxes_Part18;
    class UStaticMeshComponent* SM_Hoxxes_Part17;
    class UStaticMeshComponent* SM_Hoxxes_Part16;
    class UStaticMeshComponent* SM_Hoxxes_Part15;
    class UStaticMeshComponent* SM_Hoxxes_Part14;
    class UStaticMeshComponent* SM_Hoxxes_Part13;
    class UStaticMeshComponent* SM_Hoxxes_Part12;
    class UStaticMeshComponent* SM_Hoxxes_Part11;
    class UStaticMeshComponent* SM_Hoxxes_Part10;
    class UStaticMeshComponent* SM_Hoxxes_Part09;
    class UStaticMeshComponent* SM_Hoxxes_Part08;
    class UStaticMeshComponent* SM_Hoxxes_Part07;
    class UStaticMeshComponent* SM_Hoxxes_Part06;
    class UStaticMeshComponent* SM_Hoxxes_Part05;
    class UStaticMeshComponent* SM_Hoxxes_Part04;
    class UStaticMeshComponent* SM_Hoxxes_Part03;
    class UStaticMeshComponent* SM_Hoxxes_Part02;
    class UStaticMeshComponent* SM_Hoxxes_Part01;
    class UStaticMeshComponent* SM_Hoxxes_Part35;
    class USceneComponent* PlanetParts;
    class USceneComponent* Scene;
    float Scale;

    void UserConstructionScript();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Hoxxes01(int32 EntryPoint);
};

#endif
