#ifndef UE4SS_SDK_BP_BoscoVacuum_HPP
#define UE4SS_SDK_BP_BoscoVacuum_HPP

class ABP_BoscoVacuum_C : public ADroneVacuumStream
{
    class UParticleSystemComponent* ParticleSystem;

};

#endif
