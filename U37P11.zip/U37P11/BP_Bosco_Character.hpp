#ifndef UE4SS_SDK_BP_Bosco_Character_HPP
#define UE4SS_SDK_BP_Bosco_Character_HPP

class ABP_Bosco_Character_C : public ABP_PlayerCharacter_C
{
};

#endif
