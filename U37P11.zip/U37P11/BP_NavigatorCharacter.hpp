#ifndef UE4SS_SDK_BP_NavigatorCharacter_HPP
#define UE4SS_SDK_BP_NavigatorCharacter_HPP

class ABP_NavigatorCharacter_C : public ABP_PlayerCharacter_C
{
};

#endif
