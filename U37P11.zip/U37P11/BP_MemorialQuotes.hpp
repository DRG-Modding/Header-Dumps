#ifndef UE4SS_SDK_BP_MemorialQuotes_HPP
#define UE4SS_SDK_BP_MemorialQuotes_HPP

class ABP_MemorialQuotes_C : public AActor
{
    class UStaticMeshComponent* Cube;
    class UWidgetComponent* Widget;
    class USceneComponent* DefaultSceneRoot;

};

#endif
