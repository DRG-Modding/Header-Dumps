#ifndef UE4SS_SDK_AFL_Frozen_Player_HPP
#define UE4SS_SDK_AFL_Frozen_Player_HPP

class UAFL_Frozen_Player_C : public UScalingMeshAfflictionEffect
{
};

#endif
