#ifndef UE4SS_SDK_BP_RefineryDNA_HPP
#define UE4SS_SDK_BP_RefineryDNA_HPP

class UBP_RefineryDNA_C : public UMissionDNA
{
    int32 RoomCount;

};

#endif
