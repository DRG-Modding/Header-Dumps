#ifndef UE4SS_SDK_BP_Phys_Barrel01_Red_HPP
#define UE4SS_SDK_BP_Phys_Barrel01_Red_HPP

class ABP_Phys_Barrel01_Red_C : public ABP_Phys_Barrel01_C
{
};

#endif
