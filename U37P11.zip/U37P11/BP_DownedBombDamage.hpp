#ifndef UE4SS_SDK_BP_DownedBombDamage_HPP
#define UE4SS_SDK_BP_DownedBombDamage_HPP

class UBP_DownedBombDamage_C : public UDamageComponent
{
};

#endif
