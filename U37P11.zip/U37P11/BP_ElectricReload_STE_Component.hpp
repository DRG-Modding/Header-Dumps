#ifndef UE4SS_SDK_BP_ElectricReload_STE_Component_HPP
#define UE4SS_SDK_BP_ElectricReload_STE_Component_HPP

class UBP_ElectricReload_STE_Component_C : public UWeaponHitCounterComponent
{
};

#endif
