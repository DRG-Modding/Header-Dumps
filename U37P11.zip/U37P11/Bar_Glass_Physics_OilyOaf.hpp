#ifndef UE4SS_SDK_Bar_Glass_Physics_OilyOaf_HPP
#define UE4SS_SDK_Bar_Glass_Physics_OilyOaf_HPP

class ABar_Glass_Physics_OilyOaf_C : public ABar_Glass_Physics_C
{
};

#endif
