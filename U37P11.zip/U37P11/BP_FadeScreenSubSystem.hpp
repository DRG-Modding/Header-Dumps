#ifndef UE4SS_SDK_BP_FadeScreenSubSystem_HPP
#define UE4SS_SDK_BP_FadeScreenSubSystem_HPP

class UBP_FadeScreenSubSystem_C : public UFadeScreenSubSystem
{
};

#endif
