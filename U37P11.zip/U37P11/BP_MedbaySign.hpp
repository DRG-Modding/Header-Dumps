#ifndef UE4SS_SDK_BP_MedbaySign_HPP
#define UE4SS_SDK_BP_MedbaySign_HPP

class ABP_MedbaySign_C : public AActor
{
    class UPointLightComponent* PointLight;
    class UStaticMeshComponent* MedbaySign;
    class USceneComponent* DefaultSceneRoot;

};

#endif
