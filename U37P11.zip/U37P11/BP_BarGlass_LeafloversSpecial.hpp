#ifndef UE4SS_SDK_BP_BarGlass_LeafloversSpecial_HPP
#define UE4SS_SDK_BP_BarGlass_LeafloversSpecial_HPP

class ABP_BarGlass_LeafloversSpecial_C : public ABP_BarGlass_Standard_C
{
};

#endif
