#ifndef UE4SS_SDK_BP_DrillerCharacter_HPP
#define UE4SS_SDK_BP_DrillerCharacter_HPP

class ABP_DrillerCharacter_C : public ABP_PlayerCharacter_C
{
};

#endif
