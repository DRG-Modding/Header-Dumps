#ifndef UE4SS_SDK_AFE_TP_MagicHoleMovement_HPP
#define UE4SS_SDK_AFE_TP_MagicHoleMovement_HPP

class UAFE_TP_MagicHoleMovement_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
