#ifndef UE4SS_SDK_BP_DamageOnReloadComponent_BRT_HPP
#define UE4SS_SDK_BP_DamageOnReloadComponent_BRT_HPP

class UBP_DamageOnReloadComponent_BRT_C : public UWeaponHitCounterComponent
{
};

#endif
