#ifndef UE4SS_SDK_BP_MotivationalQuotes_HPP
#define UE4SS_SDK_BP_MotivationalQuotes_HPP

class ABP_MotivationalQuotes_C : public AActor
{
    class UStaticMeshComponent* Mesh;
    class UWidgetComponent* Widget;
    class USceneComponent* DefaultSceneRoot;

};

#endif
