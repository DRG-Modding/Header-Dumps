#ifndef UE4SS_SDK_BP_Phys_Barrel_Cutie_HPP
#define UE4SS_SDK_BP_Phys_Barrel_Cutie_HPP

class ABP_Phys_Barrel_Cutie_C : public ABP_Phys_Barrel01_C
{
};

#endif
