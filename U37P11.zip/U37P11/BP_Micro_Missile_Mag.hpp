#ifndef UE4SS_SDK_BP_Micro_Missile_Mag_HPP
#define UE4SS_SDK_BP_Micro_Missile_Mag_HPP

class ABP_Micro_Missile_Mag_C : public AMAG_BaseClass_C
{
};

#endif
