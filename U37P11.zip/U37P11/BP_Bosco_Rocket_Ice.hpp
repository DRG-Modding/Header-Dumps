#ifndef UE4SS_SDK_BP_Bosco_Rocket_Ice_HPP
#define UE4SS_SDK_BP_Bosco_Rocket_Ice_HPP

class ABP_Bosco_Rocket_Ice_C : public ABP_BoscoAbillityProjectile_C
{
};

#endif
