#ifndef UE4SS_SDK_BP_RadarDish02_HPP
#define UE4SS_SDK_BP_RadarDish02_HPP

class ABP_RadarDish02_C : public ABP_RadarDish01_C
{
};

#endif
