#ifndef UE4SS_SDK_BP_DynamicReverb_HPP
#define UE4SS_SDK_BP_DynamicReverb_HPP

class UBP_DynamicReverb_C : public UDynamicReverbComponent
{
};

#endif
