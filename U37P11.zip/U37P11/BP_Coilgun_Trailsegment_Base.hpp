#ifndef UE4SS_SDK_BP_Coilgun_Trailsegment_Base_HPP
#define UE4SS_SDK_BP_Coilgun_Trailsegment_Base_HPP

class ABP_Coilgun_Trailsegment_Base_C : public ACoilGunTrailSegment
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
