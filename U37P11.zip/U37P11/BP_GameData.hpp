#ifndef UE4SS_SDK_BP_GameData_HPP
#define UE4SS_SDK_BP_GameData_HPP

class UBP_GameData_C : public UGameData
{
};

#endif
