#ifndef UE4SS_SDK_BP_CreateBombOnHit_DualMP_HPP
#define UE4SS_SDK_BP_CreateBombOnHit_DualMP_HPP

class UBP_CreateBombOnHit_DualMP_C : public UWeaponHitEffectComponent
{
};

#endif
