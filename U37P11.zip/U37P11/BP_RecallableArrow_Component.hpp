#ifndef UE4SS_SDK_BP_RecallableArrow_Component_HPP
#define UE4SS_SDK_BP_RecallableArrow_Component_HPP

class UBP_RecallableArrow_Component_C : public UCrossbowProjectileRecallable
{
};

#endif
