#ifndef UE4SS_SDK_BP_GrabbedState_HPP
#define UE4SS_SDK_BP_GrabbedState_HPP

class UBP_GrabbedState_C : public UGrabbedStateComponent
{
};

#endif
