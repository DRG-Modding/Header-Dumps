#ifndef UE4SS_SDK_BP_PilotingState_HPP
#define UE4SS_SDK_BP_PilotingState_HPP

class UBP_PilotingState_C : public UPilotingStateComponent
{
};

#endif
