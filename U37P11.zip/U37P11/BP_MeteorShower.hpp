#ifndef UE4SS_SDK_BP_MeteorShower_HPP
#define UE4SS_SDK_BP_MeteorShower_HPP

class ABP_MeteorShower_C : public AActor
{
    class UFSDAudioComponent* InfectedGlobe;
    class UStaticMeshComponent* SM_Plague_HologramMeteor_04;
    class UStaticMeshComponent* SM_Plague_HologramMeteor_03;
    class USceneComponent* Holo2;
    class UStaticMeshComponent* SM_Plague_HologramMeteor_01;
    class UStaticMeshComponent* SM_Plague_HologramMeteor_02;
    class USceneComponent* Holo1;
    class USceneComponent* DefaultSceneRoot;

};

#endif
