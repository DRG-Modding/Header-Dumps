#ifndef UE4SS_SDK_BP_ExterminationContract_HPP
#define UE4SS_SDK_BP_ExterminationContract_HPP

class UBP_ExterminationContract_C : public UExterminationReward
{
};

#endif
