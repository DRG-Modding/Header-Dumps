#ifndef UE4SS_SDK_BP_MonitorPanel_HPP
#define UE4SS_SDK_BP_MonitorPanel_HPP

class ABP_MonitorPanel_C : public AActor
{
    class UWidgetComponent* Widget;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* DefaultSceneRoot;

};

#endif
