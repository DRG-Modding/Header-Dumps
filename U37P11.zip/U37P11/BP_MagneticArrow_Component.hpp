#ifndef UE4SS_SDK_BP_MagneticArrow_Component_HPP
#define UE4SS_SDK_BP_MagneticArrow_Component_HPP

class UBP_MagneticArrow_Component_C : public UCrossbowProjectileMagnetic
{
};

#endif
