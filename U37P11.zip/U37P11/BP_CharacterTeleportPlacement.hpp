#ifndef UE4SS_SDK_BP_CharacterTeleportPlacement_HPP
#define UE4SS_SDK_BP_CharacterTeleportPlacement_HPP

class UBP_CharacterTeleportPlacement_C : public UTerrainPlacementComponent
{
};

#endif
