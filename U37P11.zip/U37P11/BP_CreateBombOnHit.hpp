#ifndef UE4SS_SDK_BP_CreateBombOnHit_HPP
#define UE4SS_SDK_BP_CreateBombOnHit_HPP

class UBP_CreateBombOnHit_C : public UWeaponHitEffectComponent
{
};

#endif
