#ifndef UE4SS_SDK_BP_ExplosiveEnemiesDamageHuge_HPP
#define UE4SS_SDK_BP_ExplosiveEnemiesDamageHuge_HPP

class UBP_ExplosiveEnemiesDamageHuge_C : public UDamageComponent
{
};

#endif
