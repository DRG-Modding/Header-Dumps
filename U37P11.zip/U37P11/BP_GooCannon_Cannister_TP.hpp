#ifndef UE4SS_SDK_BP_GooCannon_Cannister_TP_HPP
#define UE4SS_SDK_BP_GooCannon_Cannister_TP_HPP

class ABP_GooCannon_Cannister_TP_C : public ABP_GooCannon_Cannister_C
{
};

#endif
