#ifndef UE4SS_SDK_AFE_TP_Pheromones_HPP
#define UE4SS_SDK_AFE_TP_Pheromones_HPP

class UAFE_TP_Pheromones_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
