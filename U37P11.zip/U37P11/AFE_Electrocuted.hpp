#ifndef UE4SS_SDK_AFE_Electrocuted_HPP
#define UE4SS_SDK_AFE_Electrocuted_HPP

class UAFE_Electrocuted_C : public UBoneParticlesAfflictionEffect
{
};

#endif
