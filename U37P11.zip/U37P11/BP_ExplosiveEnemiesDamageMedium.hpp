#ifndef UE4SS_SDK_BP_ExplosiveEnemiesDamageMedium_HPP
#define UE4SS_SDK_BP_ExplosiveEnemiesDamageMedium_HPP

class UBP_ExplosiveEnemiesDamageMedium_C : public UDamageComponent
{
};

#endif
