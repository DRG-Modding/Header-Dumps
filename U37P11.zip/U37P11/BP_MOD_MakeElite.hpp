#ifndef UE4SS_SDK_BP_MOD_MakeElite_HPP
#define UE4SS_SDK_BP_MOD_MakeElite_HPP

class UBP_MOD_MakeElite_C : public UMOD_MakeEliteEnemy
{
};

#endif
