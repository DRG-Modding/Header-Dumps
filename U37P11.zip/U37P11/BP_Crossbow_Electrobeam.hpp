#ifndef UE4SS_SDK_BP_Crossbow_Electrobeam_HPP
#define UE4SS_SDK_BP_Crossbow_Electrobeam_HPP

class ABP_Crossbow_Electrobeam_C : public ACrossbowElectroBeam
{
};

#endif
