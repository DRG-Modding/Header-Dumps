#ifndef UE4SS_SDK_BP_BarGlass_DarkMorkite_HPP
#define UE4SS_SDK_BP_BarGlass_DarkMorkite_HPP

class ABP_BarGlass_DarkMorkite_C : public ABP_BarGlass_Standard_C
{
};

#endif
