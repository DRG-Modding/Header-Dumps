#ifndef UE4SS_SDK_BP_Bosco_Rocket_Frag_HPP
#define UE4SS_SDK_BP_Bosco_Rocket_Frag_HPP

class ABP_Bosco_Rocket_Frag_C : public ABP_BoscoAbillityProjectile_C
{
};

#endif
