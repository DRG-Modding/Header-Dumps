#ifndef UE4SS_SDK_BP_HoverBootsBurnTrigger_HPP
#define UE4SS_SDK_BP_HoverBootsBurnTrigger_HPP

class ABP_HoverBootsBurnTrigger_C : public AActor
{
    class USphereComponent* Sphere;
    class UStatusEffectTriggerComponent* StatusEffectTrigger;
    class USceneComponent* DefaultSceneRoot;

};

#endif
