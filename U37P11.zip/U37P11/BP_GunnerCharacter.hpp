#ifndef UE4SS_SDK_BP_GunnerCharacter_HPP
#define UE4SS_SDK_BP_GunnerCharacter_HPP

class ABP_GunnerCharacter_C : public ABP_PlayerCharacter_C
{
};

#endif
