#ifndef UE4SS_SDK_BP_FlyingState_HPP
#define UE4SS_SDK_BP_FlyingState_HPP

class UBP_FlyingState_C : public UFlyingStateComponent
{
};

#endif
