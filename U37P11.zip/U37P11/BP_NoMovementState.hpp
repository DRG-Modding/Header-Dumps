#ifndef UE4SS_SDK_BP_NoMovementState_HPP
#define UE4SS_SDK_BP_NoMovementState_HPP

class UBP_NoMovementState_C : public UNoMovementStateComponent
{
};

#endif
