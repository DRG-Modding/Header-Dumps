#ifndef UE4SS_SDK_BP_PhotographyState_HPP
#define UE4SS_SDK_BP_PhotographyState_HPP

class UBP_PhotographyState_C : public UPhotographyStateComponent
{
};

#endif
