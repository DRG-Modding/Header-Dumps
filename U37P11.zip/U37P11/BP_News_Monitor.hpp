#ifndef UE4SS_SDK_BP_News_Monitor_HPP
#define UE4SS_SDK_BP_News_Monitor_HPP

class ABP_News_Monitor_C : public AActor
{
    class UStaticMeshComponent* Mesh;
    class UWidgetComponent* Widget;
    class USceneComponent* DefaultSceneRoot;

};

#endif
