#ifndef UE4SS_SDK_BP_DorettaHead_SpaceRig_HPP
#define UE4SS_SDK_BP_DorettaHead_SpaceRig_HPP

class ABP_DorettaHead_SpaceRig_C : public AActor
{
    class UStaticMeshComponent* SM_Cart3;
    class UStaticMeshComponent* SM_ToolPile_03;
    class UStaticMeshComponent* SM_ToolPile_02;
    class UStaticMeshComponent* SM_ToolBox_01;
    class UStaticMeshComponent* SM_MetalPanel_Skirting_A_Connector1;
    class UStaticMeshComponent* E;
    class UStaticMeshComponent* SM_MetalPanel_Skirting_A_Connector;
    class UStaticMeshComponent* SM_MetalPlate_01;
    class UStaticMeshComponent* SM_MetalPanel_Skirting_A_Connector270d;
    class UStaticMeshComponent* SM_Cart2;
    class UStaticMeshComponent* SM_Cart1;
    class UStaticMeshComponent* SM_Cart;
    class USeamlessTravelEventActivator* SeamlessTravelEventActivator;
    class UStaticMeshComponent* SM_Doretta;
    class USceneComponent* DefaultSceneRoot;

};

#endif
