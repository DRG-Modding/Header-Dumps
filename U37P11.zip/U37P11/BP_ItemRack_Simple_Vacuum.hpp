#ifndef UE4SS_SDK_BP_ItemRack_Simple_Vacuum_HPP
#define UE4SS_SDK_BP_ItemRack_Simple_Vacuum_HPP

class ABP_ItemRack_Simple_Vacuum_C : public ABP_ItemRack_Simple_C
{
};

#endif
