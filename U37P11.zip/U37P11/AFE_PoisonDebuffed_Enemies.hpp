#ifndef UE4SS_SDK_AFE_PoisonDebuffed_Enemies_HPP
#define UE4SS_SDK_AFE_PoisonDebuffed_Enemies_HPP

class UAFE_PoisonDebuffed_Enemies_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
