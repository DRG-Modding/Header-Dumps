#ifndef UE4SS_SDK_Bar_Glass_Physics_GlyphidSlammer_HPP
#define UE4SS_SDK_Bar_Glass_Physics_GlyphidSlammer_HPP

class ABar_Glass_Physics_GlyphidSlammer_C : public ABar_Glass_Physics_C
{
};

#endif
