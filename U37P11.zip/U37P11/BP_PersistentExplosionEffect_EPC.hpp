#ifndef UE4SS_SDK_BP_PersistentExplosionEffect_EPC_HPP
#define UE4SS_SDK_BP_PersistentExplosionEffect_EPC_HPP

class ABP_PersistentExplosionEffect_EPC_C : public ABP_Damage_Cloud_Base_C
{
};

#endif
