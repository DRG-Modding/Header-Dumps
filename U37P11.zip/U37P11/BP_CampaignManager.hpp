#ifndef UE4SS_SDK_BP_CampaignManager_HPP
#define UE4SS_SDK_BP_CampaignManager_HPP

class UBP_CampaignManager_C : public UCampaignManager
{
};

#endif
