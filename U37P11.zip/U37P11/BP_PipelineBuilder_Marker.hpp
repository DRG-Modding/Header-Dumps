#ifndef UE4SS_SDK_BP_PipelineBuilder_Marker_HPP
#define UE4SS_SDK_BP_PipelineBuilder_Marker_HPP

class ABP_PipelineBuilder_Marker_C : public ABP_ItemMarker_Base_C
{
};

#endif
