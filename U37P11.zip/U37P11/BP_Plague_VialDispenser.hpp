#ifndef UE4SS_SDK_BP_Plague_VialDispenser_HPP
#define UE4SS_SDK_BP_Plague_VialDispenser_HPP

class ABP_Plague_VialDispenser_C : public AActor
{
    class UPointLightComponent* PointLight1;
    class UPointLightComponent* PointLight;
    class UWidgetComponent* ScreenWidget;
    class UStaticMeshComponent* SM_Plague_VialVendingMachine;
    class USceneComponent* DefaultSceneRoot;

};

#endif
