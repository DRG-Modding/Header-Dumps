#ifndef UE4SS_SDK_BP_Grenade_IFG_Area_SlowAndWeak_HPP
#define UE4SS_SDK_BP_Grenade_IFG_Area_SlowAndWeak_HPP

class ABP_Grenade_IFG_Area_SlowAndWeak_C : public ABP_Grenade_IFG_Area_Base_C
{
};

#endif
