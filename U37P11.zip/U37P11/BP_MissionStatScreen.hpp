#ifndef UE4SS_SDK_BP_MissionStatScreen_HPP
#define UE4SS_SDK_BP_MissionStatScreen_HPP

class ABP_MissionStatScreen_C : public AActor
{
    class UWidgetComponent* Widget;
    class USceneComponent* DefaultSceneRoot;

};

#endif
