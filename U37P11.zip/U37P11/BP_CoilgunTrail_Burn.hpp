#ifndef UE4SS_SDK_BP_CoilgunTrail_Burn_HPP
#define UE4SS_SDK_BP_CoilgunTrail_Burn_HPP

class ABP_CoilgunTrail_Burn_C : public ABP_CoilgunTrail_Base_C
{
};

#endif
