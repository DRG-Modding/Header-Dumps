#ifndef UE4SS_SDK_BP_Geyser_Base_HPP
#define UE4SS_SDK_BP_Geyser_Base_HPP

class ABP_Geyser_Base_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
