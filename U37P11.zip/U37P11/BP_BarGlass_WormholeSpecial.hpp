#ifndef UE4SS_SDK_BP_BarGlass_WormholeSpecial_HPP
#define UE4SS_SDK_BP_BarGlass_WormholeSpecial_HPP

class ABP_BarGlass_WormholeSpecial_C : public ABP_BarGlass_Standard_C
{
};

#endif
