#ifndef UE4SS_SDK_BP_BansheeModule_Component_HPP
#define UE4SS_SDK_BP_BansheeModule_Component_HPP

class UBP_BansheeModule_Component_C : public UCrossbowStuckProjectileEffectBanshee
{
};

#endif
