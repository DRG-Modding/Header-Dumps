#ifndef UE4SS_SDK_BP_ExplosiveReloadComponent_DualMP_HPP
#define UE4SS_SDK_BP_ExplosiveReloadComponent_DualMP_HPP

class UBP_ExplosiveReloadComponent_DualMP_C : public UWeaponHitCounterComponent
{
};

#endif
