#ifndef UE4SS_SDK_BP_FracturedMissionDNA_HPP
#define UE4SS_SDK_BP_FracturedMissionDNA_HPP

class UBP_FracturedMissionDNA_C : public UMissionDNA
{
    float RoomDistance;

};

#endif
