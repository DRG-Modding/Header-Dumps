#ifndef UE4SS_SDK_BP_ExplosiveEnemiesDamageTiny_HPP
#define UE4SS_SDK_BP_ExplosiveEnemiesDamageTiny_HPP

class UBP_ExplosiveEnemiesDamageTiny_C : public UDamageComponent
{
};

#endif
