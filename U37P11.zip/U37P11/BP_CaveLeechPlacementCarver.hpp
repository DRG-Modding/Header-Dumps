#ifndef UE4SS_SDK_BP_CaveLeechPlacementCarver_HPP
#define UE4SS_SDK_BP_CaveLeechPlacementCarver_HPP

class ABP_CaveLeechPlacementCarver_C : public AActor
{
    class ULevelGenerationCarverComponent* LevelGenerationCarver;
    class USceneComponent* DefaultSceneRoot;

};

#endif
