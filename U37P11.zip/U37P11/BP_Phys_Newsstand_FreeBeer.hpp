#ifndef UE4SS_SDK_BP_Phys_Newsstand_FreeBeer_HPP
#define UE4SS_SDK_BP_Phys_Newsstand_FreeBeer_HPP

class ABP_Phys_Newsstand_FreeBeer_C : public ABP_Phys_Newsstand_C
{
};

#endif
