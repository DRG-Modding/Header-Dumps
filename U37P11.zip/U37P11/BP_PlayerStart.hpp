#ifndef UE4SS_SDK_BP_PlayerStart_HPP
#define UE4SS_SDK_BP_PlayerStart_HPP

class ABP_PlayerStart_C : public AFSDPlayerStart
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
