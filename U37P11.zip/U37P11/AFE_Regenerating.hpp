#ifndef UE4SS_SDK_AFE_Regenerating_HPP
#define UE4SS_SDK_AFE_Regenerating_HPP

class UAFE_Regenerating_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
