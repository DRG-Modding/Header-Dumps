#ifndef UE4SS_SDK_BP_CoilgunTrail_Base_HPP
#define UE4SS_SDK_BP_CoilgunTrail_Base_HPP

class ABP_CoilgunTrail_Base_C : public ACoilgunWeaponTrail
{
};

#endif
