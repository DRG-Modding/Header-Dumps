#ifndef UE4SS_SDK_AIC_Spider_Boss_TwinA_HPP
#define UE4SS_SDK_AIC_Spider_Boss_TwinA_HPP

class AAIC_Spider_Boss_TwinA_C : public AAIC_Spider_Boss_TwinBase_C
{
};

#endif
