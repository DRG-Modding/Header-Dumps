#ifndef UE4SS_SDK_Basic_Hover_Bracket_HPP
#define UE4SS_SDK_Basic_Hover_Bracket_HPP

class UBasic_Hover_Bracket_C : public UUserWidget
{
    class UImage* Image_699;
    class UImage* Image_763;
    class UImage* Image_910;

};

#endif
