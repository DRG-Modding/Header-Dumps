#ifndef UE4SS_SDK_AFL_Gen_Burn_Small_HPP
#define UE4SS_SDK_AFL_Gen_Burn_Small_HPP

class UAFL_Gen_Burn_Small_C : public UBurningAfflictionEffect
{
};

#endif
