#ifndef UE4SS_SDK_AFE_LookAtConsole_HPP
#define UE4SS_SDK_AFE_LookAtConsole_HPP

class UAFE_LookAtConsole_C : public UPlayerCharacterMontageAfflictionEffect
{
};

#endif
