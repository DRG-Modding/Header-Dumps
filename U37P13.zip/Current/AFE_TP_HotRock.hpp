#ifndef UE4SS_SDK_AFE_TP_HotRock_HPP
#define UE4SS_SDK_AFE_TP_HotRock_HPP

class UAFE_TP_HotRock_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
