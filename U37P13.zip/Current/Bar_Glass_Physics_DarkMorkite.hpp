#ifndef UE4SS_SDK_Bar_Glass_Physics_DarkMorkite_HPP
#define UE4SS_SDK_Bar_Glass_Physics_DarkMorkite_HPP

class ABar_Glass_Physics_DarkMorkite_C : public ABar_Glass_Physics_C
{
};

#endif
