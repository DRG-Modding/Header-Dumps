#ifndef UE4SS_SDK_AIC_Spider_Grunt_Infection_HPP
#define UE4SS_SDK_AIC_Spider_Grunt_Infection_HPP

class AAIC_Spider_Grunt_Infection_C : public AAIC_Spider_Grunt_C
{
};

#endif
