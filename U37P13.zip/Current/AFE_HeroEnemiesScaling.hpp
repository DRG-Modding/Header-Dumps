#ifndef UE4SS_SDK_AFE_HeroEnemiesScaling_HPP
#define UE4SS_SDK_AFE_HeroEnemiesScaling_HPP

class UAFE_HeroEnemiesScaling_C : public UEnemyScaleAfflictionEffect
{
};

#endif
