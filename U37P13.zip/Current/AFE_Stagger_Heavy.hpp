#ifndef UE4SS_SDK_AFE_Stagger_Heavy_HPP
#define UE4SS_SDK_AFE_Stagger_Heavy_HPP

class UAFE_Stagger_Heavy_C : public UStaggeredAfflictionEffect
{
};

#endif
