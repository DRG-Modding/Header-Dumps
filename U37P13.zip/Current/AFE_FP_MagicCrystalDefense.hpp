#ifndef UE4SS_SDK_AFE_FP_MagicCrystalDefense_HPP
#define UE4SS_SDK_AFE_FP_MagicCrystalDefense_HPP

class UAFE_FP_MagicCrystalDefense_C : public UAttachedParticlesAfflictionEffect
{
};

#endif
